import express from 'express';
import {
  create,
  getAll,
  getById,
  update,
  remove
} from '../controllers/productController.js';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// 📋 Obtener todas las soluciones/productos (PÚBLICO para visitantes y cotizador)
router.get('/', getAll);

// 🔎 Obtener una solución por ID (PÚBLICO)
router.get('/:id', getById);

// ➕ Crear solución (solo admin)
router.post('/', authMiddleware, adminMiddleware, create);

// ✏️ Actualizar solución (solo admin)
router.put('/:id', authMiddleware, adminMiddleware, update);

// 🗑️ Eliminar solución (solo admin)
router.delete('/:id', authMiddleware, adminMiddleware, remove);

export default router;
