#!/bin/bash
# ==============================================================================
# 🚀 PRO CAM Seguridad Web 2.0 — Script de Instalación Automatizada para VPS Ubuntu
# Compatible con Ubuntu 20.04 / 22.04 / 24.04 LTS (Hostinger, Hetzner, DigitalOcean)
# ==============================================================================

set -e

echo "=================================================="
echo "🛡️ INICIANDO CONFIGURACIÓN DE API PRO CAM EN VPS"
echo "=================================================="

# 1. Actualizar repositorios
echo "📦 Actualizando paquetes del sistema..."
sudo apt update && sudo apt upgrade -y

# 2. Instalar Node.js 20 LTS y herramientas base
echo "⚙️ Instalando Node.js 20 LTS, Nginx y Git..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs nginx git certbot python3-certbot-nginx ufw

# 3. Instalar PM2 para gestión de procesos 24/7
echo "🚀 Instalando PM2 (Process Manager)..."
sudo npm install -g pm2

# 4. Instalar dependencias de producción del proyecto
echo "📥 Instalando dependencias de Node.js..."
npm install --production

# 5. Configurar Nginx Reverse Proxy para api.procamseguridad.com.ar
echo "🌐 Configurando Nginx Reverse Proxy..."
NGINX_CONF="/etc/nginx/sites-available/procam-api"

sudo tee $NGINX_CONF > /dev/null << 'EOF'
server {
    listen 80;
    server_name api.procamseguridad.com.ar;

    client_max_body_size 25M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

sudo ln -sf $NGINX_CONF /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# 6. Configurar Firewall UFW
echo "🔒 Configurando Firewall (SSH, HTTP, HTTPS)..."
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw --force enable

# 7. Iniciar la aplicación con PM2
echo "⚡ Arrancando servidor con PM2..."
pm2 delete procam-api 2>/dev/null || true
pm2 start backend/server.js --name "procam-api"
pm2 save
pm2 startup systemd -u $USER --hp $HOME 2>/dev/null || true

echo ""
echo "=================================================="
echo "✅ ¡API DE PRO CAM CONFIGURADA Y CORRIENDO EN VPS!"
echo "=================================================="
echo "📍 Puerto Local: 3000"
echo "🌐 Dominio Proxy: api.procamseguridad.com.ar"
echo "🔍 Estado PM2:"
pm2 status
echo ""
echo "👉 PASO FINAL TRAS APUNTAR EL SUBDOMINIO DNS:"
echo "Ejecutá este comando para activar el certificado SSL gratuito (HTTPS):"
echo "sudo certbot --nginx -d api.procamseguridad.com.ar"
echo "=================================================="
