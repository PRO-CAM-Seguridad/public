import Promotion from '../models/Promotion.js';
import { validationResult } from 'express-validator';

// 🎁 Crear promoción
export async function create(req, res) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { nombre, tipo, valor, segmento, fechaInicio, fechaFin } = req.body;

    const promo = new Promotion({
      nombre,          // Ej: "Promo Primavera"
      tipo,            // Ej: "porcentaje" o "fijo"
      valor,           // Ej: 10% o $5000
      segmento,        // Ej: "Hogar", "Empresas", "Smart"
      fechaInicio,
      fechaFin,
      activa: true
    });

    await promo.save();
    res.status(201).json({ success: true, message: 'Promoción creada con éxito', promo });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al crear promoción', error: err.message });
  }
}

// 📋 Listar promociones activas
export async function getAll(req, res) {
  try {
    const promos = await Promotion.find({ activa: true });
    res.json({ success: true, count: promos.length, promos });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener promociones', error: err.message });
  }
}

// 🔍 Obtener promoción por ID
export async function getById(req, res) {
  try {
    const promo = await Promotion.findById(req.params.id);
    if (!promo) return res.status(404).json({ success: false, message: 'Promoción no encontrada' });
    res.json({ success: true, promo });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener promoción', error: err.message });
  }
}

// ✏️ Actualizar promoción
export async function update(req, res) {
  try {
    const promo = await Promotion.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!promo) return res.status(404).json({ success: false, message: 'Promoción no encontrada' });
    res.json({ success: true, message: 'Promoción actualizada', promo });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al actualizar promoción', error: err.message });
  }
}

// 🗑️ Eliminar promoción
export async function remove(req, res) {
  try {
    const promo = await Promotion.findByIdAndDelete(req.params.id);
    if (!promo) return res.status(404).json({ success: false, message: 'Promoción no encontrada' });
    res.json({ success: true, message: 'Promoción eliminada' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al eliminar promoción', error: err.message });
  }
}
