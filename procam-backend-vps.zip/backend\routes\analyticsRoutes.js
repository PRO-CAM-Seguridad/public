import express from 'express';
import {
  getOverview,
  getQuotationStatusMetrics,
  getSegmentMetrics,
  getCampaignMetrics,
  getAnalyticsReport,
  getDashboardKPIs
} from '../controllers/analyticsController.js';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// Todas las rutas analíticas son administrativas
router.use(authMiddleware, adminMiddleware);

// 📊 Métricas generales (Visitas, Prospectos, Cotizaciones, Conversión)
router.get('/overview', getOverview);

// 🎯 KPIs Avanzados (Geografía, Dispositivos, Segmento Líder, Solución Top)
router.get('/kpis', getDashboardKPIs);

// 📋 Métricas por estado de cotizaciones
router.get('/status', getQuotationStatusMetrics);

// 📈 Métricas por segmento (Hogar, Empresas, Smart)
router.get('/segments', getSegmentMetrics);

// 📍 Métricas por campaña QR
router.get('/campaigns', getCampaignMetrics);

// 🔍 Reporte analítico consolidado
router.get('/report', getAnalyticsReport);

export default router;
