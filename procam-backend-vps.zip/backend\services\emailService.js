import nodemailer from 'nodemailer';

/**
 * Servicio de envío de emails para PRO CAM Seguridad
 * Soporta configuración SMTP vía variables de entorno (.env)
 * Manejo tolerante a fallos: un error SMTP no interrumpe el guardado en base de datos.
 */

function createTransporter() {
  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT, 10) || 587;
  const secure = process.env.SMTP_SECURE === 'true' || port === 465;
  const user = process.env.SMTP_USER || process.env.EMAIL_USER;
  const pass = process.env.SMTP_PASS || process.env.EMAIL_PASS;

  if (!host && !user) {
    return null;
  }

  return nodemailer.createTransport({
    host: host || 'smtp.gmail.com',
    port,
    secure,
    auth: {
      user,
      pass
    },
    tls: {
      rejectUnauthorized: false
    }
  });
}

/**
 * Notifica al equipo comercial de PRO CAM sobre una nueva solicitud de cotización
 */
export async function sendQuotationNotificationToAdmin({ quotation, prospect }) {
  const adminMail = process.env.MAIL_TO || 'ventas@procamseguridad.com.ar';
  const mailFrom = process.env.MAIL_FROM || process.env.SMTP_FROM || process.env.EMAIL_USER || 'no-reply@procamseguridad.com.ar';

  const transporter = createTransporter();
  if (!transporter) {
    console.warn('⚠️ [SMTP] Configuración de correo incompleta en .env. Notificación de cotización no enviada por email, pero guardada en MongoDB.');
    return { sent: false, reason: 'SMTP no configurado' };
  }

  const itemsHtml = quotation.items.map(item => `
    <tr style="border-bottom: 1px solid #eeeeee;">
      <td style="padding: 10px; font-weight: 600;">${item.nombre}</td>
      <td style="padding: 10px; text-align: center;">${item.cantidad} ${item.unidad || 'Unidad'}</td>
      <td style="padding: 10px; color: #666;">${item.segmento || '-'} / ${item.nivel || '-'}</td>
    </tr>
  `).join('');

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 650px; margin: 0 auto; color: #222; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;">
      <div style="background-color: #1A1A1A; padding: 24px; text-align: center; border-bottom: 4px solid #F5B800;">
        <h1 style="color: #F5B800; margin: 0; font-size: 24px; letter-spacing: 1px;">PRO CAM SEGURIDAD</h1>
        <p style="color: #FFFFFF; margin: 6px 0 0; font-size: 13px;">Nueva Solicitud de Cotización Online</p>
      </div>

      <div style="padding: 24px;">
        <div style="background-color: #FFF9E6; border-left: 4px solid #F5B800; padding: 12px 16px; margin-bottom: 20px;">
          <p style="margin: 0; font-weight: bold; color: #333;">Solicitud N°: <span style="color: #b40e02;">${quotation.numero}</span></p>
          <p style="margin: 4px 0 0; font-size: 13px; color: #666;">Fecha: ${new Date(quotation.fechaCreacion).toLocaleString('es-AR')}</p>
        </div>

        <h3 style="color: #1A1A1A; border-bottom: 2px solid #f0f0f0; padding-bottom: 6px;">📋 Datos del Prospecto</h3>
        <table style="width: 100%; font-size: 14px; margin-bottom: 20px;">
          <tr><td style="padding: 6px 0; width: 140px; color: #777;">Nombre / Contacto:</td><td style="font-weight: 600;">${prospect.nombre}</td></tr>
          ${prospect.empresa ? `<tr><td style="padding: 6px 0; color: #777;">Empresa:</td><td style="font-weight: 600;">${prospect.empresa}</td></tr>` : ''}
          <tr><td style="padding: 6px 0; color: #777;">Email:</td><td><a href="mailto:${prospect.email}" style="color: #0066cc;">${prospect.email}</a></td></tr>
          <tr><td style="padding: 6px 0; color: #777;">Teléfono / Celular:</td><td style="font-weight: 600;">${prospect.telefono}</td></tr>
          ${prospect.localidad ? `<tr><td style="padding: 6px 0; color: #777;">Localidad / Zona:</td><td>${prospect.localidad}</td></tr>` : ''}
          ${prospect.observaciones ? `<tr><td style="padding: 6px 0; color: #777;">Observaciones:</td><td style="background: #f7f7f7; padding: 8px; border-radius: 4px;">${prospect.observaciones}</td></tr>` : ''}
        </table>

        <h3 style="color: #1A1A1A; border-bottom: 2px solid #f0f0f0; padding-bottom: 6px;">🛡️ Solución y Equipos Seleccionados</h3>
        <table style="width: 100%; border-collapse: collapse; font-size: 14px; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f5f5f5; text-align: left;">
              <th style="padding: 10px;">Solución / Producto</th>
              <th style="padding: 10px; text-align: center;">Cantidad</th>
              <th style="padding: 10px;">Segmento / Nivel</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml}
          </tbody>
        </table>

        <h3 style="color: #1A1A1A; border-bottom: 2px solid #f0f0f0; padding-bottom: 6px;">📍 Origen y Atribución Comercial</h3>
        <table style="width: 100%; font-size: 13px; color: #555;">
          <tr><td style="padding: 4px 0; width: 140px;">Campaña / QR:</td><td style="font-weight: bold; color: #1A1A1A;">${quotation.campaignRef || 'QR-WEB'}</td></tr>
          <tr><td style="padding: 4px 0;">ID de Sesión:</td><td><code>${quotation.sessionId || 'N/A'}</code></td></tr>
        </table>
      </div>

      <div style="background-color: #f7f7f7; padding: 14px; text-align: center; font-size: 12px; color: #888;">
        PRO CAM Seguridad — Notificación automática del cotizador web 2.0
      </div>
    </div>
  `;

  try {
    const info = await transporter.sendMail({
      from: `"PRO CAM Cotizador" <${mailFrom}>`,
      to: adminMail,
      subject: `🔔 Nueva Solicitud de Cotización [${quotation.numero}] - ${prospect.nombre}`,
      html
    });
    console.log(`✅ [SMTP] Notificación enviada a ${adminMail} (${info.messageId})`);
    return { sent: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ [SMTP] Error enviando correo al administrador:', error.message);
    return { sent: false, error: error.message };
  }
}

/**
 * Envía un acuse de recibo profesional al email del prospecto
 */
export async function sendConfirmationToProspect({ quotation, prospect }) {
  const mailFrom = process.env.MAIL_FROM || process.env.SMTP_FROM || process.env.EMAIL_USER || 'no-reply@procamseguridad.com.ar';
  const transporter = createTransporter();
  if (!transporter) return { sent: false };

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;">
      <div style="background-color: #1A1A1A; padding: 24px; text-align: center; border-bottom: 4px solid #F5B800;">
        <h1 style="color: #F5B800; margin: 0; font-size: 22px;">PRO CAM SEGURIDAD</h1>
        <p style="color: #FFFFFF; margin: 4px 0 0; font-size: 13px;">Protegemos lo que más te importa</p>
      </div>

      <div style="padding: 24px;">
        <h2 style="color: #1A1A1A; font-size: 18px;">¡Hola, ${prospect.nombre}!</h2>
        <p style="font-size: 14px; line-height: 1.6; color: #444;">
          Recibimos tu solicitud de cotización <strong>${quotation.numero}</strong> correctamente.
        </p>

        <div style="background-color: #FFF9E6; border-left: 4px solid #F5B800; padding: 14px; border-radius: 4px; margin: 20px 0;">
          <p style="margin: 0; font-size: 14px; color: #333; line-height: 1.5;">
            A la brevedad, un <strong>asesor técnico comercial de PRO CAM Seguridad</strong> se pondrá en contacto contigo para analizar tu requerimiento y enviarte una propuesta personalizada adaptada a tu proyecto.
          </p>
        </div>

        <p style="font-size: 13px; color: #666;">
          Si necesitas asistencia inmediata o complementar detalles de tu instalación, puedes escribirnos directamente a 
          <a href="mailto:ventas@procamseguridad.com.ar" style="color: #0066cc; font-weight: bold;">ventas@procamseguridad.com.ar</a> o comunicarte por nuestros canales oficiales.
        </p>
      </div>

      <div style="background-color: #f7f7f7; padding: 14px; text-align: center; font-size: 12px; color: #888;">
        © ${new Date().getFullYear()} PRO CAM Seguridad. Todos los derechos reservados.
      </div>
    </div>
  `;

  try {
    const info = await transporter.sendMail({
      from: `"PRO CAM Seguridad" <${mailFrom}>`,
      to: prospect.email,
      subject: `Recibimos tu solicitud de cotización [${quotation.numero}] - PRO CAM Seguridad`,
      html
    });
    return { sent: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ [SMTP] Error enviando confirmación al prospecto:', error.message);
    return { sent: false, error: error.message };
  }
}

/**
 * 📧 Envía la propuesta comercial formal modelada por el Asesor Comercial al Cliente
 */
export async function sendProposalEmailToClient({ quotation, prospect, advisor, proposalDetails = {} }) {
  const mailFrom = process.env.MAIL_FROM || process.env.SMTP_FROM || process.env.EMAIL_USER || 'ventas@procamseguridad.com.ar';
  const transporter = createTransporter();
  if (!transporter) return { sent: false, reason: 'SMTP no configurado' };

  const advisorName = advisor?.nombre || quotation.asesorAsignado?.nombre || 'Gonzalo Nicolás Rojas';
  const advisorCargo = advisor?.cargo || quotation.asesorAsignado?.cargo || 'Especialistas en soluciones integrales de seguridad electrónica';
  const advisorTel = advisor?.telefono || quotation.asesorAsignado?.telefono || '+ 54 11 2394-0806';

  const itemsRows = (quotation.items || []).map(it => `
    <tr style="border-bottom: 1px solid #eee;">
      <td style="padding: 10px; font-weight: 600;">${it.nombre}</td>
      <td style="padding: 10px; text-align: center;">${it.cantidad} ${it.unidad || 'Unidad'}</td>
      <td style="padding: 10px; text-align: right; color: #555;">$${Number(it.precioUnitario || 0).toLocaleString('es-AR')}</td>
      <td style="padding: 10px; text-align: right; font-weight: bold; color: #111;">$${Number((it.precioUnitario || 0) * (it.cantidad || 1)).toLocaleString('es-AR')}</td>
    </tr>
  `).join('');

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 680px; margin: 0 auto; color: #222; border: 1px solid #e0e0e0; border-radius: 10px; overflow: hidden; background: #ffffff;">
      <!-- Header Institucional -->
      <div style="background-color: #000000; padding: 25px; text-align: center; border-bottom: 4px solid #b40e02;">
        <h1 style="color: #ffffff; margin: 0; font-size: 22px; letter-spacing: 1px;">
          <span style="color:#ffffff;">PRO</span> <span style="color:#b40e02;">CAM</span> SEGURIDAD
        </h1>
        <p style="color: #cccccc; margin: 6px 0 0; font-size: 13px;">Protegemos lo que más te importa | Propuesta Técnico Comercial</p>
      </div>

      <div style="padding: 26px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #f0f0f0; padding-bottom: 12px; margin-bottom: 20px;">
          <div>
            <span style="font-size: 13px; color: #888; text-transform: uppercase;">Presupuesto Oficial</span>
            <h2 style="margin: 2px 0 0; color: #b40e02; font-size: 20px;">N° ${quotation.numero}</h2>
          </div>
          <div style="text-align: right;">
            <span style="font-size: 12px; color: #666;">Fecha de Emisión</span>
            <div style="font-weight: bold; font-size: 14px;">${new Date().toLocaleDateString('es-AR')}</div>
          </div>
        </div>

        <p style="font-size: 15px; line-height: 1.6; margin-bottom: 16px;">
          Estimado/a <strong>${prospect?.nombre || 'Cliente'}</strong>${prospect?.empresa ? ` (${prospect.empresa})` : ''}:
        </p>
        <p style="font-size: 14px; line-height: 1.6; color: #444; margin-bottom: 20px;">
          A continuación, presentamos el desglose de la solución técnica formulada especialmente para su proyecto:
        </p>

        <!-- Tabla de Items -->
        <table style="width: 100%; border-collapse: collapse; font-size: 14px; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f7f7f7; text-align: left; border-bottom: 2px solid #ddd;">
              <th style="padding: 10px;">Solución / Servicio</th>
              <th style="padding: 10px; text-align: center;">Cantidad</th>
              <th style="padding: 10px; text-align: right;">Precio Unit.</th>
              <th style="padding: 10px; text-align: right;">Subtotal</th>
            </tr>
          </thead>
          <tbody>
            ${itemsRows}
          </tbody>
        </table>

        <!-- Resumen Financiero -->
        <div style="background-color: #fafafa; border: 1px solid #ebebeb; border-radius: 8px; padding: 16px; margin-bottom: 22px;">
          <div style="display: flex; justify-content: space-between; font-size: 14px; margin-bottom: 6px;">
            <span>Subtotal:</span>
            <span>$${Number(quotation.subtotal || 0).toLocaleString('es-AR')}</span>
          </div>
          ${quotation.descuentoMonto > 0 ? `
            <div style="display: flex; justify-content: space-between; font-size: 14px; color: #2E7D32; margin-bottom: 6px;">
              <span>Descuento aplicado (${quotation.descuentoPorcentaje || 0}%):</span>
              <span>-$${Number(quotation.descuentoMonto).toLocaleString('es-AR')}</span>
            </div>
          ` : ''}
          ${quotation.recargoMonto > 0 ? `
            <div style="display: flex; justify-content: space-between; font-size: 14px; color: #B45309; margin-bottom: 6px;">
              <span>Recargo / Instalación (${quotation.recargoPorcentaje || 0}%):</span>
              <span>+$${Number(quotation.recargoMonto).toLocaleString('es-AR')}</span>
            </div>
          ` : ''}
          <div style="display: flex; justify-content: space-between; font-size: 18px; font-weight: bold; color: #000; border-top: 2px solid #ddd; padding-top: 10px; margin-top: 6px;">
            <span>TOTAL DE LA PROPUESTA:</span>
            <span style="color: #b40e02;">$${Number(quotation.total || quotation.subtotal || 0).toLocaleString('es-AR')}</span>
          </div>
        </div>

        ${quotation.observaciones || proposalDetails.mensaje ? `
          <div style="background: #FFF8E1; border-left: 4px solid #FFA000; padding: 12px 16px; border-radius: 4px; font-size: 13px; color: #555; margin-bottom: 22px;">
            <strong>Observaciones Técnicas:</strong>
            <p style="margin: 4px 0 0; color: #333;">${proposalDetails.mensaje || quotation.observaciones}</p>
          </div>
        ` : ''}

        ${quotation.mercadoPagoLink ? `
          <div style="text-align: center; margin: 24px 0;">
            <a href="${quotation.mercadoPagoLink}" target="_blank" style="background: #009EE3; color: #ffffff; text-decoration: none; padding: 12px 28px; border-radius: 8px; font-weight: bold; font-size: 15px; display: inline-block;">
              💳 Abonar Cotización con Mercado Pago
            </a>
          </div>
        ` : ''}

        <!-- Firma Digital Institucional Homologada -->
        <div style="margin-top: 30px; padding: 16px; border: 1px solid #E2E8F0; border-radius: 8px; background: #ffffff;">
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="width: 150px; text-align: center; vertical-align: middle; border-right: 2px solid #E2E8F0; padding-right: 18px;">
                <div style="font-weight: 900; font-size: 20px; color: #000; letter-spacing: -0.5px;">
                  PRO <span style="color: #b40e02;">CAM</span>
                </div>
                <div style="font-size: 9px; font-weight: 800; color: #666; letter-spacing: 1.5px; margin-top: 3px;">
                  SEGURIDAD INTEGRAL
                </div>
              </td>
              <td style="padding-left: 18px; vertical-align: middle; font-size: 13px; line-height: 1.45;">
                <div style="font-size: 16px; font-weight: 800; color: #000000; margin-bottom: 2px;">
                  ${advisorName}
                </div>
                <div style="color: #444444; margin-bottom: 6px; font-size: 12px;">
                  ${advisorCargo}
                </div>
                <div style="font-weight: 800; color: #000000; font-size: 12px; margin-bottom: 3px;">
                  <span style="color: #b40e02;">PRO CAM</span> - Protegemos lo que más te importa
                </div>
                <div style="color: #666666; font-size: 12px;">Buenos Aires, Argentina</div>
                <div style="color: #666666; font-size: 12px;">Tel: ${advisorTel}</div>
                <div style="color: #666666; font-size: 12px; margin-top: 2px;">
                  <a href="mailto:ventas@procamseguridad.com.ar" style="color: #b40e02; text-decoration: none;">ventas@procamseguridad.com.ar</a> | 
                  <a href="https://www.procamseguridad.com.ar" style="color: #111; text-decoration: none;">www.procamseguridad.com.ar</a>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>

      <div style="background-color: #f7f7f7; padding: 14px; text-align: center; font-size: 12px; color: #888;">
        PRO CAM Seguridad — Documento emitido electrónicamente. Validez de la oferta: 15 días corridos.
      </div>
    </div>
  `;

  try {
    const info = await transporter.sendMail({
      from: `"PRO CAM Seguridad" <${mailFrom}>`,
      to: prospect.email,
      subject: `Presupuesto Oficial [${quotation.numero}] - PRO CAM Seguridad`,
      html
    });
    return { sent: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ [SMTP] Error enviando cotización formal al prospecto:', error.message);
    return { sent: false, error: error.message };
  }
}