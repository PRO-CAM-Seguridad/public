import Review from '../models/Review.js';

// 🌟 Semillas por defecto si no hay reseñas
const DEFAULT_REVIEWS = [
  {
    autor: 'Martín García',
    tipoCliente: 'Cliente Hogar',
    cargo: 'Propietario Residencial',
    ciudad: 'Quilmes',
    comentario: 'El cotizador nos facilitó armar el proyecto para la casa. Luego vino el técnico, revisó la ubicación de las cámaras y la instalación fue impecable.',
    estrellas: 5,
    activo: true,
    orden: 1
  },
  {
    autor: 'Carlos Medina',
    tipoCliente: 'Cliente Pyme',
    cargo: 'Gerente Operativo — PyME Logística',
    ciudad: 'Avellaneda',
    comentario: 'Integramos el control de acceso biométrico con las cámaras AcuSense en nuestro centro de distribución. Redujimos falsas alarmas y mejoramos el control de ingresos.',
    estrellas: 5,
    activo: true,
    orden: 2
  },
  {
    autor: 'Laura Fernández',
    tipoCliente: 'Empresa',
    cargo: 'Directora de Planta — Parque Industrial',
    ciudad: 'Bella Vista (Zona Oeste)',
    comentario: 'Excelente respuesta ante urgencias y un soporte técnico que realmente atiende el teléfono. Recomendamos a PRO CAM para comercios e industrias de gran escala.',
    estrellas: 5,
    activo: true,
    orden: 3
  }
];

/**
 * 📋 Obtener reseñas públicas (para frontend)
 */
export async function getPublicReviews(req, res) {
  try {
    let reviews = await Review.find({ activo: true }).sort({ orden: 1, fechaCreacion: -1 });
    
    // Si la base de datos está vacía, sembrar las iniciales
    if (!reviews || reviews.length === 0) {
      reviews = await Review.insertMany(DEFAULT_REVIEWS);
    }

    res.json({ success: true, count: reviews.length, reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener reseñas', error: err.message });
  }
}

/**
 * 📋 Obtener todas las reseñas (para panel Admin)
 */
export async function getAllReviewsAdmin(req, res) {
  try {
    const { tipoCliente } = req.query;
    const query = {};
    if (tipoCliente) query.tipoCliente = tipoCliente;

    let reviews = await Review.find(query).sort({ orden: 1, fechaCreacion: -1 });
    if (!reviews || reviews.length === 0) {
      reviews = await Review.insertMany(DEFAULT_REVIEWS);
    }

    res.json({ success: true, count: reviews.length, reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener reseñas administrativas', error: err.message });
  }
}

/**
 * ➕ Crear una nueva reseña (Solo Admin)
 */
export async function createReview(req, res) {
  try {
    const { autor, tipoCliente, cargo, ciudad, comentario, estrellas, activo, orden } = req.body;
    if (!autor || !comentario) {
      return res.status(400).json({ success: false, message: 'Autor y comentario son requeridos' });
    }

    const review = new Review({
      autor: autor.trim(),
      tipoCliente: tipoCliente || 'Cliente Hogar',
      cargo: cargo ? cargo.trim() : undefined,
      ciudad: ciudad ? ciudad.trim() : undefined,
      comentario: comentario.trim(),
      estrellas: Number(estrellas) || 5,
      activo: activo !== false,
      orden: Number(orden) || 0
    });

    await review.save();
    res.status(201).json({ success: true, message: 'Reseña creada con éxito', review });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al crear reseña', error: err.message });
  }
}

/**
 * ✏️ Actualizar una reseña existente (Solo Admin)
 */
export async function updateReview(req, res) {
  try {
    const review = await Review.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!review) {
      return res.status(404).json({ success: false, message: 'Reseña no encontrada' });
    }
    res.json({ success: true, message: 'Reseña actualizada con éxito', review });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al actualizar reseña', error: err.message });
  }
}

/**
 * 🗑️ Eliminar una reseña (Solo Admin)
 */
export async function deleteReview(req, res) {
  try {
    const review = await Review.findByIdAndDelete(req.params.id);
    if (!review) {
      return res.status(404).json({ success: false, message: 'Reseña no encontrada' });
    }
    res.json({ success: true, message: 'Reseña eliminada con éxito' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al eliminar reseña', error: err.message });
  }
}
