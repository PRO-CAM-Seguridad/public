import express from 'express';
import {
  create,
  getAll,
  getById,
  update,
  remove
} from '../controllers/promotionController.js';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// 📋 Obtener todas las promociones (usuarios logueados)
router.get('/', authMiddleware, getAll);

// 🔎 Obtener una promoción por ID (usuarios logueados)
router.get('/:id', authMiddleware, getById);

// ➕ Crear promoción (solo admin)
router.post('/', authMiddleware, adminMiddleware, create);

// ✏️ Actualizar promoción (solo admin)
router.put('/:id', authMiddleware, adminMiddleware, update);

// 🗑️ Eliminar promoción (solo admin)
router.delete('/:id', authMiddleware, adminMiddleware, remove);

export default router;
