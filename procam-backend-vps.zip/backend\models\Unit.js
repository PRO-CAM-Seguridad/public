import mongoose from 'mongoose';

const unitSchema = new mongoose.Schema({
  nombre: { type: String, required: true, unique: true, trim: true }, // Ej: "Unidad", "Metro", "Kit", "Servicio", "Equipo"
  abreviatura: { type: String, required: true, trim: true }, // Ej: "un", "m", "kit", "serv"
  activo: { type: Boolean, default: true },
  fechaCreacion: { type: Date, default: Date.now }
});

export default mongoose.model('Unit', unitSchema);
