import Campaign from '../models/Campaign.js';
import Visit from '../models/Visit.js';

/**
 * 📍 Registrar visita y atribución de campaña (Acceso Público)
 */
export async function registerVisit(req, res) {
  try {
    const {
      sessionId,
      campaignRef = 'QR-WEB',
      canal,
      pieza,
      solucion,
      zona,
      dispositivo,
      navegador,
      os,
      landingPage,
      referrer
    } = req.body;

    if (!sessionId) {
      return res.status(400).json({ success: false, message: 'sessionId es requerido.' });
    }

    const codigoCampana = (campaignRef || 'QR-WEB').toUpperCase().trim();
    const ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'Desconocida';

    // 1. Guardar visita
    const visit = new Visit({
      sessionId,
      campaignRef: codigoCampana,
      canal: canal || '',
      pieza: pieza || '',
      solucion: solucion || '',
      zona: zona || '',
      ip: typeof ip === 'string' ? ip.split(',')[0].trim() : 'Desconocida',
      dispositivo: dispositivo || 'Desconocido',
      navegador,
      os,
      landingPage,
      referrer
    });
    await visit.save();

    // 2. Incrementar contador en la campaña (o crearla si no existe)
    await Campaign.findOneAndUpdate(
      { codigo: codigoCampana },
      {
        $inc: { visitas: 1 },
        $setOnInsert: {
          nombre: `Campaña ${codigoCampana}`,
          canal: canal || (codigoCampana.startsWith('QR') ? 'offline_qr' : 'web'),
          pieza: pieza || 'General',
          solucion: solucion || 'Todas',
          zona: zona || 'General',
          activo: true
        }
      },
      { upsert: true, new: true }
    );

    res.status(201).json({
      success: true,
      tracked: true,
      campaignRef: codigoCampana
    });
  } catch (error) {
    console.error('❌ Error registrando visita:', error);
    res.status(500).json({ success: false, message: 'Error registrando visita', error: error.message });
  }
}

/**
 * 📋 Obtener todas las campañas y sus métricas de conversión (Solo Admin)
 */
export async function getCampaigns(req, res) {
  try {
    const campaigns = await Campaign.find().sort({ fechaCreacion: -1 });

    const formatted = campaigns.map(c => {
      const conversionRate = c.visitas > 0 ? ((c.cotizaciones / c.visitas) * 100).toFixed(1) : 0;
      return {
        _id: c._id,
        codigo: c.codigo,
        nombre: c.nombre,
        canal: c.canal || 'offline_qr',
        pieza: c.pieza || 'General',
        solucion: c.solucion || 'Todas',
        zona: c.zona || 'General',
        qrUrl: c.qrUrl || '',
        descripcion: c.descripcion,
        activo: c.activo,
        visitas: c.visitas,
        cotizaciones: c.cotizaciones,
        conversionRate: `${conversionRate}%`,
        fechaCreacion: c.fechaCreacion
      };
    });

    res.json({ success: true, count: formatted.length, campaigns: formatted });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener campañas', error: error.message });
  }
}

/**
 * ➕ Crear una nueva campaña / QR (Solo Admin)
 */
export async function createCampaign(req, res) {
  try {
    const { codigo, nombre, canal, pieza, solucion, zona, qrUrl, descripcion } = req.body;

    if (!codigo || !nombre) {
      return res.status(400).json({ success: false, message: 'Código y nombre son obligatorios.' });
    }

    const codigoNorm = codigo.toUpperCase().trim();
    const existing = await Campaign.findOne({ codigo: codigoNorm });
    if (existing) {
      return res.status(400).json({ success: false, message: 'El código de campaña ya existe.' });
    }

    const campaign = new Campaign({
      codigo: codigoNorm,
      nombre: nombre.trim(),
      canal: canal || 'offline_qr',
      pieza: pieza?.trim() || 'General',
      solucion: solucion?.trim() || 'Todas',
      zona: zona?.trim() || 'General',
      qrUrl: qrUrl?.trim() || '',
      descripcion: descripcion?.trim()
    });

    await campaign.save();
    res.status(201).json({ success: true, message: 'Campaña creada con éxito', campaign });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al crear campaña', error: error.message });
  }
}

/**
 * ✏️ Actualizar campaña (Solo Admin)
 */
export async function updateCampaign(req, res) {
  try {
    const campaign = await Campaign.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!campaign) {
      return res.status(404).json({ success: false, message: 'Campaña no encontrada' });
    }
    res.json({ success: true, message: 'Campaña actualizada', campaign });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al actualizar campaña', error: error.message });
  }
}

/**
 * 🗑️ Eliminar campaña (Solo Admin)
 */
export async function deleteCampaign(req, res) {
  try {
    const campaign = await Campaign.findByIdAndDelete(req.params.id);
    if (!campaign) {
      return res.status(404).json({ success: false, message: 'Campaña no encontrada' });
    }
    res.json({ success: true, message: 'Campaña eliminada' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al eliminar campaña', error: error.message });
  }
}
