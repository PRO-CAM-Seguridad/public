import mongoose from 'mongoose';

const cartSessionSchema = new mongoose.Schema({
  cartId: { type: String, required: true, index: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  items: [
    {
      id: String,
      nombre: String,
      precio: Number,
      cantidad: { type: Number, default: 1 }
    }
  ],
  total: { type: Number, default: 0 },
  ipPublica: { type: String, default: 'Desconocida' },
  dispositivo: { type: String, default: 'Desconocido' }, // Ej: "iPhone XR", "Chrome - Windows 11"
  qrOrigen: {
    type: String,
    default: 'QR-WEB',
    trim: true,
    index: true
    // Ejemplos: QR-WEB, QR-INSTAGRAM, QR-CCTV, QR-ALARMA, QR-VIDEOPORTERO, QR-EMPRESAS, QR-ALIADOS...
  },
  urlConsulta: { type: String },
  referrer: { type: String },
  estado: {
    type: String,
    enum: ['creado', 'actualizado', 'en_checkout', 'pagado', 'vaciado'],
    default: 'creado'
  },
  fechaCreacion: { type: Date, default: Date.now, index: true },
  fechaActualizacion: { type: Date, default: Date.now }
});

export default mongoose.model('CartSession', cartSessionSchema);
