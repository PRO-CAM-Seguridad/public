import Prospect from '../models/Prospect.js';
import Quotation from '../models/Quotation.js';
import User from '../models/User.js';

/**
 * 📋 Obtener todos los prospectos con filtros y paginación (Solo Admin)
 */
export async function getAllProspects(req, res) {
  try {
    const { estado, campaign, search, page = 1, limit = 50, sort = 'urgency' } = req.query;
    const query = {};

    if (estado) query.estado = estado;
    if (campaign) query.campaignRef = campaign.toUpperCase();
    if (search) {
      query.$or = [
        { nombre: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { telefono: { $regex: search, $options: 'i' } },
        { empresa: { $regex: search, $options: 'i' } }
      ];
    }

    const prospects = await Prospect.find(query)
      .sort({ fechaCreacion: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    const total = await Prospect.countDocuments(query);

    // Calcular SLA, tiempo sin atender y enriquecer número de ticket
    const now = new Date();
    let enrichedProspects = await Promise.all(prospects.map(async (p) => {
      const obj = p.toObject();

      // Si no tiene número de ticket vinculado, buscar su cotización más reciente
      if (!obj.ticketNumero) {
        const q = await Quotation.findOne({ prospect: p._id }).sort({ fechaCreacion: -1 });
        if (q) {
          obj.ticketNumero = q.numero;
          obj.quotationId = q._id;
        }
      }

      // Tiempo transcurrido de atención
      const fechaRef = obj.fechaUltimoContacto || obj.fechaCreacion;
      const diffMs = now - new Date(fechaRef);
      const diffMins = Math.max(1, Math.floor(diffMs / (1000 * 60)));
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      let tiempoTexto = '';
      if (diffDays > 0) {
        tiempoTexto = `${diffDays}d ${diffHours % 24}h`;
      } else if (diffHours > 0) {
        tiempoTexto = `${diffHours}h ${diffMins % 60}m`;
      } else {
        tiempoTexto = `${diffMins} min`;
      }

      // Nivel de SLA:
      // 🔴 'danger' = más de 24h sin atender en estado ABIERTO/NUEVO
      // 🟡 'warning' = 4h a 24h en estado ABIERTO, o más de 3 días en TRATAMIENTO sin contacto
      // 🟢 'ok' = menos de 4h o cerrado
      let slaStatus = 'ok';
      if (obj.estado === 'ABIERTO' || obj.estado === 'NUEVO') {
        if (diffHours >= 24) slaStatus = 'danger';
        else if (diffHours >= 4) slaStatus = 'warning';
      } else if (obj.estado === 'EN TRATAMIENTO' || obj.estado === 'REFLOTADO') {
        if (diffDays >= 3) slaStatus = 'warning';
      }

      obj.tiempoSinAtender = tiempoTexto;
      obj.slaStatus = slaStatus;
      obj.horasSinAtender = diffHours;
      obj.minutosSinAtender = diffMins;
      return obj;
    }));

    // Priorizar por orden de urgencia (mayor tiempo en estado de espera sin atender primero)
    if (sort === 'urgency') {
      enrichedProspects.sort((a, b) => {
        const aFinal = a.estado === 'CERRADO' || a.estado === 'CAIDO';
        const bFinal = b.estado === 'CERRADO' || b.estado === 'CAIDO';
        if (aFinal && !bFinal) return 1;
        if (!aFinal && bFinal) return -1;
        return (b.minutosSinAtender || 0) - (a.minutosSinAtender || 0);
      });
    }

    // Calcular resumen general de KPIs de embudo comercial
    const totalAll = await Prospect.countDocuments();
    const convertedCount = await Prospect.countDocuments({
      $or: [
        { ticketNumero: { $exists: true, $ne: '' } },
        { quotationId: { $ne: null } }
      ]
    });
    const caidosCount = await Prospect.countDocuments({ estado: 'CAIDO' });
    const convRate = totalAll > 0 ? ((convertedCount / totalAll) * 100).toFixed(1) + '%' : '0%';
    const urgentCount = enrichedProspects.filter(p => p.slaStatus === 'danger').length;

    res.json({
      success: true,
      total,
      page: Number(page),
      totalPages: Math.ceil(total / limit),
      summary: {
        totalAll,
        urgentCount,
        convertedCount,
        conversionRate: convRate,
        caidosCount
      },
      prospects: enrichedProspects
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener prospectos', error: error.message });
  }
}

/**
 * 📋 Convertir Prospecto a Cotización Oficial (Solo Admin/Ventas)
 */
export async function convertToQuotation(req, res) {
  try {
    const prospect = await Prospect.findById(req.params.id);
    if (!prospect) {
      return res.status(404).json({ success: false, message: 'Prospecto no encontrado' });
    }

    const year = new Date().getFullYear();
    const count = await Quotation.countDocuments();
    const sequence = String(count + 1).padStart(4, '0');
    const numero = `COT-${year}-${sequence}`;

    const quotation = new Quotation({
      numero,
      prospect: prospect._id,
      items: [
        {
          nombre: 'Relevamiento Técnico & Diagnóstico de Seguridad',
          segmento: prospect.tipoCliente === 'empresa' ? 'Empresas' : 'Hogar',
          nivel: 'Esencial',
          categoria: 'Videovigilancia & CCTV',
          unidad: 'Servicio',
          cantidad: 1,
          precioUnitario: 0,
          subtotal: 0
        }
      ],
      subtotal: 0,
      total: 0,
      observaciones: prospect.observaciones || 'Cotización iniciada desde el embudo comercial de prospectos.',
      campaignRef: prospect.campaignRef || 'QR-WEB',
      sessionId: prospect.sessionId,
      estado: 'EN TRATAMIENTO',
      asesorAsignado: prospect.asesorAsignado || {
        nombre: req.user?.nombre || 'Gonzalo Nicolás Rojas',
        cargo: 'Asesor Técnico Comercial',
        telefono: '+54 11 2394 0806',
        email: req.user?.email || 'ventas@procamseguridad.com.ar'
      },
      historial: [
        {
          fecha: new Date(),
          estadoAnterior: 'PROSPECTO',
          estadoNuevo: 'EN TRATAMIENTO',
          usuario: req.user?.email || 'Asesor Comercial',
          comentario: `Prospecto convertido a Cotización formal #${numero}`
        }
      ]
    });

    await quotation.save();

    prospect.ticketNumero = numero;
    prospect.quotationId = quotation._id;
    prospect.estado = 'EN TRATAMIENTO';
    prospect.fechaUltimoContacto = new Date();
    await prospect.save();

    res.status(201).json({
      success: true,
      message: `Prospecto convertido a Cotización #${numero} con éxito`,
      quotation
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al convertir prospecto a cotización', error: error.message });
  }
}

/**
 * 👔 Asignar Asesor Comercial al Prospecto (Solo Admin/Ventas)
 */
export async function assignAdvisor(req, res) {
  try {
    let { asesorId, asesorNombre, asesorEmail, asesorCargo, asesorTelefono } = req.body;
    
    if (asesorId && !asesorNombre) {
      const user = await User.findById(asesorId);
      if (user) {
        asesorNombre = user.nombre;
        asesorEmail = user.email;
        asesorCargo = user.cargo || 'Asesor Técnico Comercial';
        asesorTelefono = user.telefono || '';
      }
    }

    if (!asesorNombre) {
      return res.status(400).json({ success: false, message: 'El asesor no fue especificado o no existe' });
    }

    const prospect = await Prospect.findByIdAndUpdate(
      req.params.id,
      {
        asesorAsignado: {
          id: asesorId || undefined,
          nombre: asesorNombre.trim(),
          email: asesorEmail?.trim() || '',
          cargo: asesorCargo?.trim() || 'Asesor Técnico Comercial',
          telefono: asesorTelefono?.trim() || ''
        },
        fechaUltimoContacto: new Date()
      },
      { new: true }
    );

    if (!prospect) {
      return res.status(404).json({ success: false, message: 'Prospecto no encontrado' });
    }

    res.json({ success: true, message: `Asesor ${asesorNombre} asignado con éxito`, prospect });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al asignar asesor', error: error.message });
  }
}

/**
 * 🔍 Obtener un prospecto con su historial de cotizaciones (Solo Admin)
 */
export async function getProspectById(req, res) {
  try {
    const prospect = await Prospect.findById(req.params.id);
    if (!prospect) {
      return res.status(404).json({ success: false, message: 'Prospecto no encontrado' });
    }

    const quotations = await Quotation.find({ prospect: prospect._id })
      .sort({ fechaCreacion: -1 });

    res.json({
      success: true,
      prospect,
      quotations
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener detalle del prospecto', error: error.message });
  }
}

/**
 * ✏️ Actualizar estado o notas de un prospecto (Solo Admin)
 */
export async function updateProspect(req, res) {
  try {
    const { estado, notasInternas, telefono, localidad, empresa } = req.body;
    const updateData = {};

    if (estado) updateData.estado = estado;
    if (notasInternas !== undefined) updateData.notasInternas = notasInternas;
    if (telefono) updateData.telefono = telefono;
    if (localidad) updateData.localidad = localidad;
    if (empresa !== undefined) updateData.empresa = empresa;

    const prospect = await Prospect.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    );

    if (!prospect) {
      return res.status(404).json({ success: false, message: 'Prospecto no encontrado' });
    }

    res.json({ success: true, message: 'Prospecto actualizado con éxito', prospect });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al actualizar prospecto', error: error.message });
  }
}

/**
 * 🗑️ Eliminar un prospecto (Solo Root/Admin)
 */
export async function deleteProspect(req, res) {
  try {
    const prospect = await Prospect.findByIdAndDelete(req.params.id);
    if (!prospect) {
      return res.status(404).json({ success: false, message: 'Prospecto no encontrado' });
    }
    res.json({ success: true, message: 'Prospecto eliminado' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al eliminar prospecto', error: error.message });
  }
}

/**
 * 📨 Registrar consulta pública desde formulario de contacto (Público)
 */
export async function createPublicContactLead(req, res) {
  try {
    const {
      nombre,
      email,
      telefono,
      localidad,
      empresa,
      asunto,
      mensaje,
      campaignRef = 'QR-WEB',
      sessionId
    } = req.body;

    if (!nombre || !nombre.trim()) {
      return res.status(400).json({ success: false, message: 'El nombre es obligatorio.' });
    }
    if (!telefono && !email) {
      return res.status(400).json({ success: false, message: 'Debe ingresar teléfono o correo de contacto.' });
    }

    const emailNorm = (email || '').toLowerCase().trim() || `contacto_${Date.now()}@procamweb.com`;
    const telNorm = (telefono || '').trim() || '-';
    const obsText = `[Consulta Web Contacto: ${asunto || 'General'}] ${mensaje || ''}`.trim();
    const codigoCampana = (campaignRef || 'QR-WEB').toUpperCase().trim();

    let prospect = await Prospect.findOne({ email: emailNorm });
    if (prospect) {
      prospect.nombre = nombre.trim();
      if (telefono) prospect.telefono = telNorm;
      if (localidad) prospect.localidad = localidad.trim();
      if (empresa) {
        prospect.empresa = empresa.trim();
        prospect.tipoCliente = 'empresa';
      }
      prospect.observaciones = prospect.observaciones
        ? `${prospect.observaciones}\n---\n${obsText}`
        : obsText;
      prospect.fechaUltimoContacto = new Date();
      await prospect.save();
    } else {
      prospect = new Prospect({
        nombre: nombre.trim(),
        email: emailNorm,
        telefono: telNorm,
        localidad: (localidad || 'GBA y alrededores').trim(),
        empresa: empresa?.trim(),
        tipoCliente: empresa ? 'empresa' : 'persona',
        observaciones: obsText,
        campaignRef: codigoCampana,
        sessionId: sessionId || 'anonymous',
        estado: 'ABIERTO',
        fechaCreacion: new Date()
      });
      await prospect.save();
    }

    res.status(201).json({
      success: true,
      message: 'Consulta registrada correctamente. Un asesor se comunicará a la brevedad.',
      prospect
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al registrar la consulta', error: error.message });
  }
}

