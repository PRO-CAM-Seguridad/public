import mongoose from 'mongoose';

const reviewSchema = new mongoose.Schema({
  autor: {
    type: String,
    required: [true, 'El nombre del autor es obligatorio'],
    trim: true
  },
  tipoCliente: {
    type: String,
    enum: ['Cliente Hogar', 'Cliente Pyme', 'Empresa'],
    default: 'Cliente Hogar'
  },
  cargo: {
    type: String,
    trim: true,
    default: 'Cliente Satisfecho'
  },
  ciudad: {
    type: String,
    trim: true,
    default: 'Buenos Aires'
  },
  comentario: {
    type: String,
    required: [true, 'El comentario o reseña es obligatorio'],
    trim: true
  },
  estrellas: {
    type: Number,
    min: 1,
    max: 5,
    default: 5
  },
  activo: {
    type: Boolean,
    default: true
  },
  orden: {
    type: Number,
    default: 0
  },
  fechaCreacion: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('Review', reviewSchema);
