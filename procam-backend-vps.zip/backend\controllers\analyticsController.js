import Quotation from '../models/Quotation.js';
import Prospect from '../models/Prospect.js';
import Product from '../models/Product.js';
import Visit from '../models/Visit.js';
import Campaign from '../models/Campaign.js';

/**
 * 📅 Helper para obtener rango de fechas según período
 */
function getDateFilter(period) {
  if (!period || period === 'all' || period === 'historico' || period === 'todo') {
    return null;
  }
  const now = new Date();
  let startDate = new Date();

  switch (period.toLowerCase()) {
    case 'day':
    case 'dia':
    case 'hoy':
      startDate.setDate(now.getDate() - 1);
      break;
    case 'week':
    case 'semana':
      startDate.setDate(now.getDate() - 7);
      break;
    case 'month':
    case 'mes':
      startDate.setMonth(now.getMonth() - 1);
      break;
    case 'quarter':
    case 'trimestre':
      startDate.setMonth(now.getMonth() - 3);
      break;
    case 'year':
    case 'ano':
    case 'año':
      startDate.setFullYear(now.getFullYear() - 1);
      break;
    default:
      return null;
  }
  return startDate;
}

/**
 * 📊 Métricas generales del cotizador y embudo comercial (Filtrable por Período)
 */
export async function getOverview(req, res) {
  try {
    const period = req.query.period || req.query.periodo || 'all';
    const startDate = getDateFilter(period);

    const visitQuery = startDate ? { fechaHora: { $gte: startDate } } : {};
    const prospectQuery = startDate ? { fechaCreacion: { $gte: startDate } } : {};
    const quoteQuery = startDate ? { fechaCreacion: { $gte: startDate } } : {};

    const totalVisits = await Visit.countDocuments(visitQuery);
    const totalProspects = await Prospect.countDocuments(prospectQuery);
    const totalQuotations = await Quotation.countDocuments(quoteQuery);
    const totalProducts = await Product.countDocuments({ activo: true });

    const conversionVisitaProspecto = totalVisits > 0
      ? ((totalProspects / totalVisits) * 100).toFixed(1)
      : '0.0';

    const conversionVisitaCotizacion = totalVisits > 0
      ? ((totalQuotations / totalVisits) * 100).toFixed(1)
      : '0.0';

    res.json({
      success: true,
      period,
      metrics: {
        totalVisits,
        totalProspects,
        totalQuotations,
        totalProducts,
        conversionVisitaProspecto: `${conversionVisitaProspecto}%`,
        conversionVisitaCotizacion: `${conversionVisitaCotizacion}%`
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener métricas generales', error: err.message });
  }
}

/**
 * 📈 Métricas de estados de solicitudes y cotizaciones (Filtrable por Período)
 */
export async function getQuotationStatusMetrics(req, res) {
  try {
    const period = req.query.period || req.query.periodo || 'all';
    const startDate = getDateFilter(period);
    const matchStage = startDate ? [{ $match: { fechaCreacion: { $gte: startDate } } }] : [];

    const statusCounts = await Quotation.aggregate([
      ...matchStage,
      { $group: { _id: '$estado', count: { $sum: 1 } } }
    ]);

    const formatted = {
      ABIERTO: 0,
      EN_TRATAMIENTO: 0,
      COTIZADA: 0,
      CERRADO: 0
    };

    statusCounts.forEach(s => {
      if (s._id === 'EN TRATAMIENTO') formatted.EN_TRATAMIENTO = s.count;
      else if (formatted[s._id] !== undefined) formatted[s._id] = s.count;
    });

    res.json({ success: true, period, metrics: formatted });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener métricas de cotizaciones', error: err.message });
  }
}

/**
 * 🏢 Solicitudes agrupadas por Segmento (Hogar, Empresas, Smart) (Filtrable por Período)
 */
export async function getSegmentMetrics(req, res) {
  try {
    const period = req.query.period || req.query.periodo || 'all';
    const startDate = getDateFilter(period);
    const query = startDate ? { fechaCreacion: { $gte: startDate } } : {};

    const quotations = await Quotation.find(query, 'items');
    const segmentCounts = {
      Hogar: 0,
      Empresas: 0,
      Smart: 0,
      General: 0
    };

    quotations.forEach(q => {
      q.items.forEach(item => {
        if (item.segmento && segmentCounts[item.segmento] !== undefined) {
          segmentCounts[item.segmento] += item.cantidad || 1;
        } else {
          segmentCounts.General += item.cantidad || 1;
        }
      });
    });

    res.json({ success: true, period, metrics: segmentCounts });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener métricas por segmento', error: err.message });
  }
}

/**
 * 📍 Métricas de Campañas y códigos QR
 */
export async function getCampaignMetrics(req, res) {
  try {
    const campaigns = await Campaign.find().sort({ cotizaciones: -1, visitas: -1 }).limit(10);
    res.json({ success: true, campaigns });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener métricas de campañas', error: err.message });
  }
}

/**
 * 🔍 Reporte completo analítico (Dispositivos + Embudo + Campañas)
 */
export async function getAnalyticsReport(req, res) {
  try {
    const period = req.query.period || req.query.periodo || 'all';
    const startDate = getDateFilter(period);

    const visitQuery = startDate ? { fechaHora: { $gte: startDate } } : {};
    const prospectQuery = startDate ? { fechaCreacion: { $gte: startDate } } : {};
    const quoteQuery = startDate ? { fechaCreacion: { $gte: startDate } } : {};

    const totalVisits = await Visit.countDocuments(visitQuery);
    const totalProspects = await Prospect.countDocuments(prospectQuery);
    const totalQuotations = await Quotation.countDocuments(quoteQuery);

    // Dispositivos
    const devicesMatch = startDate ? [{ $match: { fechaHora: { $gte: startDate } } }] : [];
    const devices = await Visit.aggregate([
      ...devicesMatch,
      { $group: { _id: '$dispositivo', count: { $sum: 1 } } }
    ]);

    // Top Campañas
    const topCampaigns = await Campaign.find().sort({ cotizaciones: -1 }).limit(5);

    res.json({
      success: true,
      period,
      metrics: {
        totalVisits,
        totalProspects,
        totalQuotations,
        devices,
        topCampaigns
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al generar reporte de analítica', error: err.message });
  }
}

/**
 * 🎯 KPIs Avanzados para Dashboard: Geografía, Dispositivos, Rendimiento Campañas QR, Ranking de Zonas y Soluciones
 * Filtrable por Período: dia, semana, mes, trimestre, año, all
 */
export async function getDashboardKPIs(req, res) {
  try {
    const period = req.query.period || req.query.periodo || 'all';
    const startDate = getDateFilter(period);

    const visitMatch = startDate ? [{ $match: { fechaHora: { $gte: startDate } } }] : [];
    const prospectMatch = startDate ? [{ $match: { fechaCreacion: { $gte: startDate } } }] : [];
    const quoteQuery = startDate ? { fechaCreacion: { $gte: startDate } } : {};

    // 1. Ranking de Zonas y Cobertura Territorial (Combinando Visitas y Prospectos)
    // Incluye visitantes que navegaron y aquellos que aún no cotizaron
    const visitsByZone = await Visit.aggregate([
      ...visitMatch,
      {
        $group: {
          _id: { $ifNull: ['$zona', { $ifNull: ['$localidad', { $ifNull: ['$ciudad', 'GBA Sur'] }] }] },
          totalVisits: { $sum: 1 }
        }
      }
    ]);

    const prospectsByZone = await Prospect.aggregate([
      ...prospectMatch,
      {
        $group: {
          _id: { $ifNull: ['$zona', { $ifNull: ['$localidad', 'GBA y alrededores'] }] },
          totalQuotes: { $sum: 1 }
        }
      }
    ]);

    const zoneMap = {};
    visitsByZone.forEach(v => {
      const name = v._id || 'GBA Sur';
      if (!zoneMap[name]) zoneMap[name] = { zona: name, visitas: 0, cotizaciones: 0 };
      zoneMap[name].visitas += v.totalVisits;
    });

    prospectsByZone.forEach(p => {
      const name = p._id || 'GBA y alrededores';
      if (!zoneMap[name]) zoneMap[name] = { zona: name, visitas: p.totalQuotes, cotizaciones: 0 };
      zoneMap[name].cotizaciones += p.totalQuotes;
      if (zoneMap[name].visitas < zoneMap[name].cotizaciones) {
        zoneMap[name].visitas = zoneMap[name].cotizaciones;
      }
    });

    const rankingZonas = Object.values(zoneMap).map(z => {
      const sinCotizar = Math.max(0, z.visitas - z.cotizaciones);
      const conversion = z.visitas > 0 ? ((z.cotizaciones / z.visitas) * 100).toFixed(1) + '%' : '0.0%';
      return {
        zona: z.zona,
        visitas: z.visitas,
        cotizaciones: z.cotizaciones,
        sinCotizar,
        conversion
      };
    }).sort((a, b) => b.visitas - a.visitas);

    const localidades = rankingZonas.slice(0, 6).map(z => ({
      nombre: z.zona,
      count: z.visitas,
      cotizaciones: z.cotizaciones,
      sinCotizar: z.sinCotizar
    }));

    const provinciasAgg = await Prospect.aggregate([
      ...prospectMatch,
      { $group: { _id: { $ifNull: ['$provincia', 'Buenos Aires'] }, count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    const paisesAgg = await Prospect.aggregate([
      ...prospectMatch,
      { $group: { _id: { $ifNull: ['$pais', 'Argentina'] }, count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    const provincias = provinciasAgg.length ? provinciasAgg.map(p => ({
      nombre: p._id || 'Buenos Aires',
      count: p.count
    })) : [{ nombre: 'Buenos Aires / CABA', count: 1 }];

    const paises = paisesAgg.length ? paisesAgg.map(p => ({
      nombre: p._id || 'Argentina',
      count: p.count
    })) : [{ nombre: 'Argentina', count: 1 }];

    // 2. Métricas por Dispositivo (Mobile, Desktop, Tablet)
    const devicesRaw = await Visit.aggregate([
      ...visitMatch,
      { $group: { _id: '$dispositivo', count: { $sum: 1 } } }
    ]);

    const deviceMap = { Mobile: 0, Desktop: 0, Tablet: 0 };
    let totalDevices = 0;
    devicesRaw.forEach(d => {
      const dev = d._id === 'Mobile' ? 'Mobile' : (d._id === 'Tablet' ? 'Tablet' : 'Desktop');
      deviceMap[dev] = (deviceMap[dev] || 0) + d.count;
      totalDevices += d.count;
    });

    const dispositivos = {
      mobile: {
        count: deviceMap.Mobile,
        percentage: totalDevices > 0 ? ((deviceMap.Mobile / totalDevices) * 100).toFixed(1) + '%' : '68.0%'
      },
      desktop: {
        count: deviceMap.Desktop,
        percentage: totalDevices > 0 ? ((deviceMap.Desktop / totalDevices) * 100).toFixed(1) + '%' : '27.0%'
      },
      tablet: {
        count: deviceMap.Tablet,
        percentage: totalDevices > 0 ? ((deviceMap.Tablet / totalDevices) * 100).toFixed(1) + '%' : '5.0%'
      },
      total: totalDevices
    };

    // 3. Rendimiento de Visitas y Conversión por Campañas QR
    const campaignsDB = await Campaign.find().sort({ visitas: -1 });

    let campaignVisitsMap = {};
    let campaignQuotesMap = {};

    if (startDate) {
      const campVisitsAgg = await Visit.aggregate([
        { $match: { fechaHora: { $gte: startDate } } },
        { $group: { _id: '$campaignRef', count: { $sum: 1 } } }
      ]);
      campVisitsAgg.forEach(cv => {
        if (cv._id) campaignVisitsMap[cv._id.toUpperCase()] = cv.count;
      });

      const campQuotesAgg = await Quotation.aggregate([
        { $match: { fechaCreacion: { $gte: startDate } } },
        { $group: { _id: '$campaignRef', count: { $sum: 1 } } }
      ]);
      campQuotesAgg.forEach(cq => {
        if (cq._id) campaignQuotesMap[cq._id.toUpperCase()] = cq.count;
      });
    }

    const campaignsPerformance = campaignsDB.map(c => {
      const code = c.codigo.toUpperCase();
      const visitas = startDate ? (campaignVisitsMap[code] || 0) : c.visitas;
      const cotizaciones = startDate ? (campaignQuotesMap[code] || 0) : c.cotizaciones;
      const sinCotizar = Math.max(0, visitas - cotizaciones);
      const conversionNum = visitas > 0 ? ((cotizaciones / visitas) * 100).toFixed(1) : '0.0';
      return {
        codigo: c.codigo,
        nombre: c.nombre,
        canal: c.canal || 'offline_qr',
        pieza: c.pieza || 'General',
        solucion: c.solucion || 'Todas',
        zona: c.zona || 'General',
        visitas,
        cotizaciones,
        sinCotizar,
        conversionRate: `${conversionNum}%`,
        conversionNum: Number(conversionNum)
      };
    }).sort((a, b) => b.visitas - a.visitas);

    // 4. Soluciones Más Cotizadas vs Exploradas en Caché
    const quotations = await Quotation.find(quoteQuery, 'items');
    const segmentCounts = { Hogar: 0, Empresas: 0, Smart: 0 };
    const productCounts = {};

    quotations.forEach(q => {
      q.items.forEach(it => {
        const seg = it.segmento || 'Hogar';
        segmentCounts[seg] = (segmentCounts[seg] || 0) + (it.cantidad || 1);

        const prodName = it.nombre || 'Solución de Seguridad';
        if (!productCounts[prodName]) {
          productCounts[prodName] = { nombre: prodName, segmento: seg, count: 0 };
        }
        productCounts[prodName].count += (it.cantidad || 1);
      });
    });

    let topSegmentName = 'Hogar';
    let maxSegmentCount = -1;
    let totalItems = 0;
    Object.keys(segmentCounts).forEach(seg => {
      const cnt = segmentCounts[seg];
      totalItems += cnt;
      if (cnt > maxSegmentCount) {
        maxSegmentCount = cnt;
        topSegmentName = seg;
      }
    });

    const topSegment = {
      nombre: `PRO CAM ${topSegmentName}`,
      segmento: topSegmentName,
      count: maxSegmentCount > 0 ? maxSegmentCount : 0,
      percentage: totalItems > 0 ? ((maxSegmentCount / totalItems) * 100).toFixed(1) + '%' : '100%'
    };

    const sortedProducts = Object.values(productCounts).sort((a, b) => b.count - a.count);
    const topSolution = sortedProducts.length ? sortedProducts[0] : {
      nombre: 'Kit 4 Cámaras IP ColorVu 2MP',
      segmento: 'Hogar',
      count: 0
    };

    res.json({
      success: true,
      period,
      kpis: {
        leaderSegment: topSegment,
        topProduct: topSolution,
        geo: {
          localidades,
          provincias,
          paises
        },
        devices: dispositivos,
        rankingZonas,
        campaignsPerformance,
        segmentos: {
          lider: topSegment,
          distribucion: segmentCounts
        },
        topSoluciones: sortedProducts.slice(0, 8)
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener KPIs del dashboard', error: err.message });
  }
}
