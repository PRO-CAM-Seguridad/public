/**
 * Controlador deprecado: el flujo de Mercado Pago fue reemplazado por quotationController.js
 */
export async function createCheckout(req, res) {
  return res.status(410).json({
    success: false,
    message: 'Mercado Pago ha sido deshabilitado. La plataforma opera como Cotizador de Soluciones con validación técnica y comercial.',
    redirect: '/productos.html'
  });
}
