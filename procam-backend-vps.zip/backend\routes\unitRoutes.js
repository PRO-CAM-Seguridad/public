import express from 'express';
import {
  getUnits,
  createUnit,
  updateUnit,
  deleteUnit
} from '../controllers/unitController.js';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// 📋 Listar unidades (PÚBLICO)
router.get('/', getUnits);

// ABM de unidades (Solo Admin)
router.post('/', authMiddleware, adminMiddleware, createUnit);
router.put('/:id', authMiddleware, adminMiddleware, updateUnit);
router.delete('/:id', authMiddleware, adminMiddleware, deleteUnit);

export default router;
