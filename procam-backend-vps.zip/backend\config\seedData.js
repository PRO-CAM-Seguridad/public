import mongoose from 'mongoose';
import dotenv from 'dotenv';
dotenv.config();

import Unit from '../models/Unit.js';
import Category from '../models/Category.js';
import Product from '../models/Product.js';
import Campaign from '../models/Campaign.js';

import User from '../models/User.js';
import bcrypt from 'bcryptjs';

export async function seedInitialData() {
  try {
    console.log('🌱 Inicializando datos base para PRO CAM Seguridad...');

    // 0. Usuario Administrador Oficial
    const existingAdmin = await User.findOne({ email: 'admin@procamseguridad.com.ar' });
    if (!existingAdmin) {
      const hash = await bcrypt.hash('173394', 10);
      await User.create({
        email: 'admin@procamseguridad.com.ar',
        password: hash,
        nombre: 'Admin PRO CAM',
        role: 'admin',
        verified: true,
        tipoCliente: 'persona',
        telefono: '1123940806',
        tipoDocumento: 'DNI',
        numeroDocumento: '99999999'
      });
      console.log('✅ Usuario Administrador inicializado.');
    }


    // 1. Unidades de Medida
    const defaultUnits = [
      { nombre: 'Kit Completo', abreviatura: 'kit' },
      { nombre: 'Unidad / Equipo', abreviatura: 'un' },
      { nombre: 'Metro lineal', abreviatura: 'm' },
      { nombre: 'Servicio / Mano de obra', abreviatura: 'serv' },
    ];

    const unitMap = {};
    for (const u of defaultUnits) {
      const unit = await Unit.findOneAndUpdate(
        { nombre: u.nombre },
        { $set: u },
        { upsert: true, new: true }
      );
      unitMap[u.abreviatura] = unit._id;
    }
    console.log('✅ Unidades de medida verificadas.');

    // 2. Categorías
    const defaultCategories = [
      { nombre: 'Videovigilancia & CCTV', descripcion: 'Sistemas de cámaras IP y análogas con inteligencia artificial' },
      { nombre: 'Alarmas & Detección', descripcion: 'Centrales cableadas e inalámbricas con comunicación 4G y WiFi' },
      { nombre: 'Control de Accesos', descripcion: 'Biometría, molinetes, reconocimiento facial y barreras vehiculares' },
      { nombre: 'Videoporteros & Intercom', descripcion: 'Sistemas de comunicación IP con monitores touch y app móvil' },
      { nombre: 'Seguridad Perimetral', descripcion: 'Cercos eléctricos homologados y barreras infrarrojas' },
      { nombre: 'Corporativo & Smart', descripcion: 'HikCentral, analítica de video avanzada y reconocimiento de patentes' }
    ];

    const categoryMap = {};
    for (const c of defaultCategories) {
      const cat = await Category.findOneAndUpdate(
        { nombre: c.nombre },
        { $set: c },
        { upsert: true, new: true }
      );
      categoryMap[c.nombre] = cat._id;
    }
    console.log('✅ Categorías verificadas.');

    // 3. Campañas QR Oficiales
    const defaultCampaigns = [
      { codigo: 'QR-WEB', nombre: 'Sitio Web Directo', canal: 'web', descripcion: 'Tráfico orgánico y directo' },
      { codigo: 'QR-INSTAGRAM', nombre: 'Instagram & Redes', canal: 'social', descripcion: 'Campañas en redes sociales' },
      { codigo: 'QR-FOLLETOS', nombre: 'Folletería de Calle', canal: 'offline_qr', descripcion: 'Material impreso zonal' },
      { codigo: 'QR-CARTELERIA', nombre: 'Cartelería Pública', canal: 'offline_qr', descripcion: 'Carteles en vía pública y obras' },
      { codigo: 'QR-CCTV', nombre: 'Campaña Videovigilancia', canal: 'offline_qr', descripcion: 'QR promocional de CCTV' },
      { codigo: 'QR-ALARMA', nombre: 'Campaña Alarmas', canal: 'offline_qr', descripcion: 'QR promocional de sistemas de alarma' },
      { codigo: 'QR-VIDEOPORTERO', nombre: 'Campaña Videoporteros', canal: 'offline_qr', descripcion: 'QR enfocado en edificios y residencias' },
      { codigo: 'QR-EMPRESAS', nombre: 'Segmento Corporativo', canal: 'offline_qr', descripcion: 'Folletos B2B y eventos empresariales' },
      { codigo: 'QR-ALIADOS', nombre: 'Red de Aliados Comerciales', canal: 'alianza', descripcion: 'Convenios con instaladores y comercios' }
    ];

    for (const cmp of defaultCampaigns) {
      await Campaign.findOneAndUpdate(
        { codigo: cmp.codigo },
        { $set: cmp },
        { upsert: true, new: true }
      );
    }
    console.log('✅ Campañas QR verificadas.');

    // 4. Catálogo de Soluciones por Segmento (Hogar, Empresas, Smart)
    const defaultProducts = [
      // ─── HOGAR ─────────────────────────────
      {
        nombre: 'PRO CAM CCTV Hogar - Esencial',
        segmento: 'Hogar',
        nivel: 'Esencial',
        categoria: categoryMap['Videovigilancia & CCTV'],
        unidad: unitMap['kit'],
        descripcion: 'Kit básico de videovigilancia ideal para frentes y accesos domiciliarios.',
        componentes: ['DVR 4 Canales 1080p', '2 Cámaras Bullet HD visión nocturna', 'Disco rígido dedicado', 'App Hik-Connect para ver en el celular', 'Fuente y cableado']
      },
      {
        nombre: 'PRO CAM CCTV Hogar - Avanzada',
        segmento: 'Hogar',
        nivel: 'Avanzada',
        categoria: categoryMap['Videovigilancia & CCTV'],
        unidad: unitMap['kit'],
        descripcion: 'Cobertura integral perimetral con detección inteligente de intrusión.',
        componentes: ['DVR 4 Canales AcuSense', '4 Cámaras Full HD intemperie con audio', 'Disco rígido de 1TB', 'Detección inteligente de personas y vehículos', 'Acceso móvil multiusuario']
      },
      {
        nombre: 'PRO CAM CCTV Hogar - Integral',
        segmento: 'Hogar',
        nivel: 'Integral',
        categoria: categoryMap['Videovigilancia & CCTV'],
        unidad: unitMap['kit'],
        descripcion: 'Máxima protección IP de alta definición para residencias amplias.',
        componentes: ['NVR 8 Canales 4K PoE', '6 Cámaras IP ColorVu (visión nocturna a todo color 24/7)', 'Disco 2TB surveillance', 'Sirena integrada y disuasión activa', 'Grabación continua y por eventos']
      },
      {
        nombre: 'PRO CAM Alarma Hogar - Esencial',
        segmento: 'Hogar',
        nivel: 'Esencial',
        categoria: categoryMap['Alarmas & Detección'],
        unidad: unitMap['kit'],
        descripcion: 'Sistema de alarma inalámbrico con aviso inmediato al smartphone.',
        componentes: ['Central Wi-Fi inalámbrica', '2 Sensores de movimiento PIR inmunes a mascotas', '1 Contacto magnético de puerta/ventana', 'Sirena interior de alta potencia', 'Control remoto tipo llavero']
      },
      {
        nombre: 'PRO CAM Alarma Hogar - Integral',
        segmento: 'Hogar',
        nivel: 'Integral',
        categoria: categoryMap['Alarmas & Detección'],
        unidad: unitMap['kit'],
        descripcion: 'Alarma de doble vía de comunicación (Wi-Fi + 4G) con respaldo energético.',
        componentes: ['Central híbrida Wi-Fi + Chip 4G', '4 Sensores de movimiento', '3 Sensores magnéticos', 'Barrera exterior para patio/jardín', 'Sirena exterior estroboscópica', 'Batería de respaldo']
      },
      {
        nombre: 'PRO CAM Video Hogar - Videoportero IP',
        segmento: 'Hogar',
        nivel: 'Esencial',
        categoria: categoryMap['Videoporteros & Intercom'],
        unidad: unitMap['kit'],
        descripcion: 'Atendé tu timbre desde la pantalla interior o directamente en tu celular.',
        componentes: ['Frente de calle exterior IP anti-vandalismo', 'Pantalla interior táctil 7" Full Color', 'Apertura remota de cerradura eléctrica', 'Intercomunicador con audio bidireccional', 'App móvil']
      },
      {
        nombre: 'PRO CAM Perimetral - Cerco Eléctrico Homologado',
        segmento: 'Hogar',
        nivel: 'Esencial',
        categoria: categoryMap['Seguridad Perimetral'],
        unidad: unitMap['m'],
        descripcion: 'Barrera física y eléctrica de máxima disuasión con alarma sonora integrada.',
        componentes: ['Electrificador homologado según normas de seguridad', 'Líneas de alambre galvanizado de alta resistencia', 'Aisladores UV premium', 'Postes de fijación reforzados', 'Sirena de disparo por corte o intrusión']
      },

      // ─── EMPRESAS ──────────────────────────
      {
        nombre: 'PRO CAM CCTV Empresas - AcuSense Comercial',
        segmento: 'Empresas',
        nivel: 'Avanzada',
        categoria: categoryMap['Videovigilancia & CCTV'],
        unidad: unitMap['kit'],
        descripcion: 'Videovigilancia corporativa con clasificación de personas y rodados para reducir falsas alarmas.',
        componentes: ['NVR Profesional 8/16 Canales', 'Cámaras IP AcuSense Varifocales', 'Perímetros virtuales y cruce de línea analítico', 'Monitoreo remoto multi-sucursal', 'Almacenamiento redundante']
      },
      {
        nombre: 'PRO CAM Alarma Comercial 4G',
        segmento: 'Empresas',
        nivel: 'Integral',
        categoria: categoryMap['Alarmas & Detección'],
        unidad: unitMap['kit'],
        descripcion: 'Protección para locales comerciales, oficinas y depósitos con respaldo de comunicación celular.',
        componentes: ['Panel de control 4G de alta seguridad', 'Sensores de rotura de cristales', 'Barreras perimetrales fotoeléctricas', 'Sensores industriales antienmascaramiento', 'Sirenas blindadas y botón de asalto']
      },
      {
        nombre: 'PRO CAM Control de Acceso Biométrico',
        segmento: 'Empresas',
        nivel: 'Avanzada',
        categoria: categoryMap['Control de Accesos'],
        unidad: unitMap['un'],
        descripcion: 'Gestión de personal, horarios y accesos mediante huella, tarjeta o reconocimiento facial.',
        componentes: ['Terminal biométrica standalone TCP/IP', 'Control de electroimán y botón de salida', 'Software de gestión y reportes de asistencia', 'Soporte hasta 3000 usuarios']
      },

      // ─── SMART / CORPORATIVO ───────────────
      {
        nombre: 'PRO CAM SMART - Centro de Monitoreo Centralizado',
        segmento: 'Smart',
        nivel: 'Integral',
        categoria: categoryMap['Corporativo & Smart'],
        unidad: unitMap['serv'],
        descripcion: 'Integración en plataforma HikCentral para video walls, multi-edificios y operadores dedicados.',
        componentes: ['Servidor HikCentral Enterprise', 'Gestión centralizada de video, alarmas y accesos', 'E-Map interactivo', 'Módulo de video wall y gestión de roles de operadores']
      },
      {
        nombre: 'PRO CAM SMART - Inteligencia de Video & Atributos',
        segmento: 'Smart',
        nivel: 'Integral',
        categoria: categoryMap['Corporativo & Smart'],
        unidad: unitMap['serv'],
        descripcion: 'Búsqueda forense inteligente por atributos físicos (color de ropa, género, vehículos, patentes).',
        componentes: ['Cámaras DeepinView con Deep Learning', 'Algoritmos de búsqueda rápida por eventos', 'Conteo de personas y mapas de calor para retail']
      },
      {
        nombre: 'PRO CAM SMART - Control Vehicular LPR / ANPR',
        segmento: 'Smart',
        nivel: 'Integral',
        categoria: categoryMap['Corporativo & Smart'],
        unidad: unitMap['kit'],
        descripcion: 'Lectura automática de patentes vehiculares y apertura de barreras automatizadas.',
        componentes: ['Cámara IP LPR para reconocimiento de matrículas', 'Controlador de barrera vehicular', 'Lista blanca / lista negra de vehículos', 'Reporte histórico de ingresos y egresos con fotografía']
      },
      {
        nombre: 'PRO CAM SMART - Prevención de Riesgos Industriales',
        segmento: 'Smart',
        nivel: 'Integral',
        categoria: categoryMap['Corporativo & Smart'],
        unidad: unitMap['kit'],
        descripcion: 'Detección temprana de incendios, humo, fugas y uso de elementos de protección personal (EPP).',
        componentes: ['Cámaras térmicas bi-espectro para detección de puntos calientes', 'Analítica de no uso de casco/EPP', 'Integración con paneles de incendio homologados']
      }
    ];

    for (const p of defaultProducts) {
      await Product.findOneAndUpdate(
        { nombre: p.nombre },
        { $set: p },
        { upsert: true, new: true }
      );
    }
    console.log('✅ Catálogo de Soluciones iniciales verificado con éxito.');

  } catch (error) {
    console.error('❌ Error ejecutando seedInitialData:', error.message);
  }
}

// Si se ejecuta directamente desde node:
if (process.argv[1]?.endsWith('seedData.js')) {
  mongoose.connect(process.env.MONGO_URI)
    .then(async () => {
      await seedInitialData();
      process.exit(0);
    })
    .catch((err) => {
      console.error('❌ Error de conexión:', err);
      process.exit(1);
    });
}
