import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  nombre: { type: String, required: true, trim: true },
  descripcion: { type: String, trim: true },
  categoria: { type: mongoose.Schema.Types.ObjectId, ref: 'Category' },
  unidad: { type: mongoose.Schema.Types.ObjectId, ref: 'Unit' },
  segmento: {
    type: String,
    enum: ['Hogar', 'Empresas', 'Smart'],
    required: true,
    index: true
  },
  nivel: {
    type: String,
    enum: ['Esencial', 'Avanzada', 'Integral'],
    required: true
  },
  componentes: [{ type: String }], // Ej: ['Cámara IP', 'Alarma', 'Acceso biométrico']
  imagen: { type: String },
  activo: { type: Boolean, default: true, index: true },
  destacado: { type: Boolean, default: false },
  precio: { type: Number, default: 0 }, // Referencia interna opcional, no expuesto al usuario
  fechaCreacion: { type: Date, default: Date.now }
});

export default mongoose.model('Product', productSchema);
