import mongoose from 'mongoose';

const campaignSchema = new mongoose.Schema({
  codigo: { type: String, required: true, unique: true, uppercase: true, trim: true, index: true }, // Ej: "QR-CCTV", "QR-WEB", "QR-ALARMA", "QR-EMPRESAS"
  nombre: { type: String, required: true, trim: true }, // Ej: "Folletería CCTV Quilmes"
  canal: { type: String, default: 'offline_qr', trim: true }, // 'offline_qr', 'social', 'web', 'alianza', 'carteleria'
  pieza: { type: String, trim: true, default: 'General' }, // 'Cartel Poste 2x1', 'Folleto A5', 'Sticker Puerta', etc.
  solucion: { type: String, trim: true, default: 'Todas' }, // Solución asociada o 'Todas'
  zona: { type: String, trim: true, default: 'General' }, // Zona territorial
  qrUrl: { type: String, trim: true },
  descripcion: { type: String, trim: true },
  activo: { type: Boolean, default: true },
  visitas: { type: Number, default: 0 },
  cotizaciones: { type: Number, default: 0 },
  fechaCreacion: { type: Date, default: Date.now }
});

export default mongoose.model('Campaign', campaignSchema);
