import mongoose from 'mongoose';

const prospectSchema = new mongoose.Schema({
  nombre: { type: String, required: true, trim: true },
  empresa: { type: String, trim: true },
  tipoCliente: { type: String, enum: ['persona', 'empresa'], default: 'persona' },
  email: { type: String, required: true, lowercase: true, trim: true, index: true },
  telefono: { type: String, required: true, trim: true },
  localidad: { type: String, trim: true, default: 'GBA y alrededores' },
  provincia: { type: String, trim: true, default: 'Buenos Aires' },
  pais: { type: String, trim: true, default: 'Argentina' },
  direccion: { type: String, trim: true },
  observaciones: { type: String, trim: true },
  campaignRef: { type: String, default: 'QR-WEB', uppercase: true, trim: true, index: true },
  sessionId: { type: String, index: true },
  estado: {
    type: String,
    enum: ['ABIERTO', 'NUEVO', 'CONTACTADO', 'EN TRATAMIENTO', 'REFLOTADO', 'CAIDO', 'CERRADO'],
    default: 'ABIERTO',
    index: true
  },
  asesorAsignado: {
    id: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    nombre: { type: String, default: 'Sin asignar' },
    email: { type: String, default: '' },
    cargo: { type: String, default: '' },
    telefono: { type: String, default: '' }
  },
  ticketNumero: { type: String, default: '' },
  quotationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Quotation' },
  fechaUltimoContacto: { type: Date, default: null },
  notasInternas: { type: String, default: '' },
  fechaCreacion: { type: Date, default: Date.now, index: true }
});

export default mongoose.model('Prospect', prospectSchema);
