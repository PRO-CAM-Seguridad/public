import express from 'express';

const router = express.Router();

// Endpoint obsoleto deprecado: redirecciona al cotizador
router.all('*', (req, res) => {
  res.status(410).json({
    success: false,
    message: 'El checkout directo ha sido reemplazado por el sistema de Solicitudes de Cotización.',
    redirect: '/productos.html'
  });
});

export default router;
