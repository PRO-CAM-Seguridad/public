import express from 'express';
import {
  getPublicReviews,
  getAllReviewsAdmin,
  createReview,
  updateReview,
  deleteReview
} from '../controllers/reviewController.js';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// 📋 Reseñas públicas (para página principal y testimoniales)
router.get('/', getPublicReviews);

// 🔒 Gestión administrativa (Solo Admin / Root)
router.get('/admin', authMiddleware, adminMiddleware, getAllReviewsAdmin);
router.post('/', authMiddleware, adminMiddleware, createReview);
router.put('/:id', authMiddleware, adminMiddleware, updateReview);
router.delete('/:id', authMiddleware, adminMiddleware, deleteReview);

export default router;
