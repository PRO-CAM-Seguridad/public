import Product from '../models/Product.js';
import { validationResult } from 'express-validator';

/**
 * 📦 Crear solución / producto (Solo Admin)
 */
export async function create(req, res) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const {
      nombre,
      descripcion,
      categoria,
      unidad,
      segmento,       // "Hogar", "Empresas", "Smart"
      nivel,          // "Esencial", "Avanzada", "Integral"
      componentes,    // Array de strings
      imagen,
      destacado = false,
      precio = 0,
      activo = true
    } = req.body;

    const product = new Product({
      nombre,
      descripcion,
      categoria: categoria || undefined,
      unidad: unidad || undefined,
      segmento,
      nivel,
      componentes: Array.isArray(componentes) ? componentes : [],
      imagen,
      destacado: Boolean(destacado),
      precio: Number(precio) || 0,
      activo: Boolean(activo)
    });

    await product.save();
    res.status(201).json({ success: true, message: 'Solución creada con éxito', product });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al crear solución', error: err.message });
  }
}

/**
 * 📋 Listar soluciones / productos (Acceso Público)
 */
export async function getAll(req, res) {
  try {
    const { segmento, nivel, categoria, search, page = 1, limit = 50, all } = req.query;
    const query = {};

    // Si no es consulta administrativa explícita, filtrar sólo activos
    if (all !== 'true') {
      query.activo = true;
    }

    if (segmento) query.segmento = segmento;
    if (nivel) query.nivel = nivel;
    if (categoria) query.categoria = categoria;
    if (search) {
      query.$or = [
        { nombre: { $regex: search, $options: 'i' } },
        { descripcion: { $regex: search, $options: 'i' } }
      ];
    }

    const products = await Product.find(query)
      .populate('categoria', 'nombre descripcion')
      .populate('unidad', 'nombre abreviatura')
      .sort({ destacado: -1, fechaCreacion: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    const total = await Product.countDocuments(query);

    res.json({
      success: true,
      count: products.length,
      total,
      products
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener soluciones', error: err.message });
  }
}

/**
 * 🔍 Obtener solución por ID (Acceso Público)
 */
export async function getById(req, res) {
  try {
    const product = await Product.findById(req.params.id)
      .populate('categoria', 'nombre descripcion')
      .populate('unidad', 'nombre abreviatura');

    if (!product) {
      return res.status(404).json({ success: false, message: 'Solución no encontrada' });
    }
    res.json({ success: true, product });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener solución', error: err.message });
  }
}

/**
 * ✏️ Actualizar solución (Solo Admin)
 */
export async function update(req, res) {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!product) return res.status(404).json({ success: false, message: 'Solución no encontrada' });
    res.json({ success: true, message: 'Solución actualizada con éxito', product });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al actualizar solución', error: err.message });
  }
}

/**
 * 🗑️ Eliminar solución (Solo Admin)
 */
export async function remove(req, res) {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: 'Solución no encontrada' });
    res.json({ success: true, message: 'Solución eliminada con éxito' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al eliminar solución', error: err.message });
  }
}
