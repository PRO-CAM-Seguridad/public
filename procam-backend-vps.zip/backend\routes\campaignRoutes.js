import express from 'express';
import {
  registerVisit,
  getCampaigns,
  createCampaign,
  updateCampaign,
  deleteCampaign
} from '../controllers/campaignController.js';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// 📍 Registro de visita y tracking QR (PÚBLICO)
router.post('/visit', registerVisit);

// Rutas de administración de campañas (Solo Admin)
router.get('/', authMiddleware, adminMiddleware, getCampaigns);
router.post('/', authMiddleware, adminMiddleware, createCampaign);
router.put('/:id', authMiddleware, adminMiddleware, updateCampaign);
router.delete('/:id', authMiddleware, adminMiddleware, deleteCampaign);

export default router;
