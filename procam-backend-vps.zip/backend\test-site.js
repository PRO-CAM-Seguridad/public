/**
 * PROCAM Seguridad Integral - Test Suite Completo
 * Verificaciones:
 * 1. Modelo User & Admin Seeding (adminprocam / 173394)
 * 2. Cambio de contraseña (change-password endpoint)
 * 3. Proceso de Carrito y Checkout diferido (Registro al pagar)
 * 4. Integración con Mercado Pago (init_point / billetera virtual)
 * 5. Adaptación de Branding 1.0 (Akzentica_4F-Bold, #b40e02, contenido institucional)
 */

const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'secretkey';

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;

function assert(condition, message) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✅ PASS: ${message}`);
  } else {
    failedTests++;
    console.error(`  ❌ FAIL: ${message}`);
  }
}

async function runTestSuite() {
  console.log('\n======================================================');
  console.log('🧪 TEST SUITE: PRO CAM SEGURIDAD INTEGRAL (VERSIÓN 1.0 + 2.0)');
  console.log('======================================================\n');

  // -----------------------------------------------------------------
  // 1. Verificación del Usuario adminprocam con clave 173394
  // -----------------------------------------------------------------
  console.log('👑 1. Verificación de Usuario adminprocam y Password por Defecto 173394');
  try {
    const seedAdmin = require('./config/seedAdmin');
    assert(typeof seedAdmin === 'function', 'Script seedAdminUser() está definido y exportado');

    const defaultPass = '173394';
    const hashed = await bcrypt.hash(defaultPass, 10);
    const valid = await bcrypt.compare('173394', hashed);
    assert(valid === true, 'Contraseña por defecto 173394 hasheada con bcrypt coincide correctamente');

    const authController = require('./controllers/authController');
    assert(typeof authController.login === 'function', 'authController.login está disponible');
    assert(typeof authController.changePassword === 'function', 'authController.changePassword está disponible');
  } catch (err) {
    assert(false, `Error en prueba de adminprocam: ${err.message}`);
  }

  // -----------------------------------------------------------------
  // 2. Verificación de Cambio de Contraseña
  // -----------------------------------------------------------------
  console.log('\n🔑 2. Verificación de Lógica de Cambio de Contraseña');
  try {
    let currentHash = await bcrypt.hash('173394', 10);
    const candidateCurrent = '173394';
    const isCurrentValid = await bcrypt.compare(candidateCurrent, currentHash);
    assert(isCurrentValid === true, 'Validación de contraseña actual correcta');

    const newPass = 'NuevaClaveSegura2026!';
    currentHash = await bcrypt.hash(newPass, 10);
    const isNewValid = await bcrypt.compare(newPass, currentHash);
    assert(isNewValid === true, 'Nueva contraseña hasheada y almacenada exitosamente');

    const isOldValid = await bcrypt.compare('173394', currentHash);
    assert(isOldValid === false, 'Contraseña antigua deja de ser válida tras el cambio');
  } catch (err) {
    assert(false, `Error en prueba de cambio de contraseña: ${err.message}`);
  }

  // -----------------------------------------------------------------
  // 3. Verificación del Checkout y Creación Diferida de Usuario
  // -----------------------------------------------------------------
  console.log('\n🛒 3. Verificación de Carrito Libre y Creación de Usuario al Pagar');
  try {
    const mainJsPath = path.join(__dirname, '../frontend/assets/js/main.js');
    const mainJsContent = fs.readFileSync(mainJsPath, 'utf-8');

    assert(mainJsContent.includes('handlePayCartClick'), 'main.js intercepta el clic en "Pagar Carrito"');
    assert(mainJsContent.includes('renderCheckoutAuthStep'), 'main.js despliega el paso de autenticación/registro únicamente al pagar');
    assert(mainJsContent.includes('executeMercadoPagoCheckout'), 'main.js ejecuta el checkout y redirección a Mercado Pago');
    assert(mainJsContent.includes('flushCart'), 'main.js cuenta con función flushCart()');
    assert(mainJsContent.includes('flushToCreateCart'), 'main.js cuenta con función flushToCreateCart()');
    assert(mainJsContent.includes('openChangePasswordModal'), 'main.js cuenta con modal para cambiar contraseña');
  } catch (err) {
    assert(false, `Error en validación de main.js: ${err.message}`);
  }

  // -----------------------------------------------------------------
  // 4. Verificación de Mercado Pago (init_point / Billetera Virtual)
  // -----------------------------------------------------------------
  console.log('\n💳 4. Verificación de Controlador Mercado Pago');
  try {
    const checkoutController = require('./controllers/checkoutController');
    assert(typeof checkoutController.createCheckout === 'function', 'checkoutController.createCheckout está definido');

    // Mock request y response
    const mockReq = {
      body: {
        items: [{ id: 'cam-hik-1', nombre: 'Kit 4 Cámaras', precio: 62900, cantidad: 1 }],
        payer: { nombre: 'Cliente Test', email: 'cliente@test.com' }
      },
      user: { id: 'mock-user-id', nombre: 'Cliente Test', email: 'cliente@test.com' }
    };

    let checkoutResult = null;
    const mockRes = {
      json: (data) => { checkoutResult = data; return mockRes; },
      status: () => mockRes
    };

    await checkoutController.createCheckout(mockReq, mockRes);
    assert(checkoutResult !== null, 'createCheckout responde con objeto JSON');
    assert(checkoutResult.init_point !== undefined, 'createCheckout devuelve init_point para redirigir a billetera virtual');
  } catch (err) {
    assert(false, `Error en checkout Mercado Pago: ${err.message}`);
  }

  // -----------------------------------------------------------------
  // 5. Verificación de Branding Versión 1.0 (Akzentica_4F-Bold & #b40e02)
  // -----------------------------------------------------------------
  console.log('\n🎨 5. Verificación de Branding, Tipografía y Contenido 1.0');
  try {
    const cssPath = path.join(__dirname, '../frontend/assets/css/style.css');
    const cssContent = fs.readFileSync(cssPath, 'utf-8');

    assert(cssContent.includes('#B40E02') || cssContent.includes('#b40e02'), 'CSS contiene el color institucional #b40e02');
    assert(cssContent.includes('Akzentica_4F-Bold') || cssContent.includes('Akzentica 4F'), 'CSS define la tipografía de marca Akzentica_4F-Bold');
    assert(cssContent.includes('font-family: Arial'), 'CSS define Arial como fuente principal de texto');
    assert(cssContent.includes('c-hero'), 'CSS incorpora la estructura hero de la versión 1.0');

    const indexPath = path.join(__dirname, '../frontend/index.html');
    const indexContent = fs.readFileSync(indexPath, 'utf-8');

    assert(indexContent.includes('images/logo-icono.jpg'), 'index.html referencia el ícono oficial con espacio dedicado (logo-icon-wrap)');
    assert(indexContent.includes('SEGURIDAD INTEGRAL'), 'index.html contiene el título de 1.0 "SEGURIDAD INTEGRAL"');
    assert(indexContent.includes('Protegemos lo que más te importa'), 'index.html contiene el subtítulo de 1.0');
    assert(indexContent.includes('Tecnología que protege, personas que responden'), 'index.html contiene contenido institucional de "Nosotros"');
    assert(indexContent.includes('Sistemas de videovigilancia'), 'index.html contiene servicio "Sistemas de videovigilancia"');
    assert(indexContent.includes('Alarmas monitoreadas'), 'index.html contiene servicio "Alarmas monitoreadas"');
    assert(indexContent.includes('Cercos Eléctricos'), 'index.html contiene servicio "Cercos Eléctricos"');
    assert(indexContent.includes('Control de accesos inteligente'), 'index.html contiene servicio "Control de accesos inteligente"');
    assert(indexContent.includes('DormiNube'), 'index.html contiene clientes institucionales de 1.0 (DormiNube, Exapol, etc.)');
    assert(indexContent.includes('+54 11 2394 0806') || indexContent.includes('5491123940806'), 'index.html contiene contacto telefónico oficial de 1.0');
  } catch (err) {
    assert(false, `Error en branding 1.0: ${err.message}`);
  }

  // -----------------------------------------------------------------
  // 6. Verificación de Pestañas de Login ("Ya estoy registrado" por defecto) y Envío de Correo
  // -----------------------------------------------------------------
  console.log('\n📧 6. Verificación de Pestañas de Login y Flujo de Verificación por Correo');
  try {
    const loginPath = path.join(__dirname, '../frontend/login.html');
    const loginContent = fs.readFileSync(loginPath, 'utf-8');

    assert(loginContent.includes('Ya estoy registrado'), 'login.html contiene la pestaña "Ya estoy registrado"');
    assert(loginContent.includes('No estoy registrado'), 'login.html contiene la pestaña "No estoy registrado"');
    assert(loginContent.includes('tab-btn-login" class="auth-tab-btn active"') || loginContent.includes('id="tab-btn-login"'), 'Pestaña "Ya estoy registrado" está configurada');
    assert(loginContent.includes('view-login-form'), 'login.html contiene el contenedor de login activo por defecto');
    assert(loginContent.includes('view-register-form'), 'login.html contiene el contenedor de registro con envío de correo');

    const authController = require('./controllers/authController');
    assert(typeof authController.verifyEmail === 'function', 'authController.verifyEmail está listo para verificar tokens');
    assert(typeof authController.register === 'function', 'authController.register está listo para enviar email y generar token');
  } catch (err) {
    assert(false, `Error en validación de login y verificación de correo: ${err.message}`);
  }

  // -----------------------------------------------------------------
  // Resumen Final
  // -----------------------------------------------------------------
  console.log('\n======================================================');
  console.log(`📊 RESULTADOS: ${passedTests}/${totalTests} pruebas superadas.`);
  if (failedTests === 0) {
    console.log('🎉 TODOS LOS REQUISITOS HAN SIDO VERIFICADOS CON ÉXITO.');
  } else {
    console.log(`⚠️ Fallaron ${failedTests} pruebas.`);
  }
  console.log('======================================================\n');
}

if (require.main === module) {
  runTestSuite();
}

module.exports = { runTestSuite };
