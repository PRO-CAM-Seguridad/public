/**
 * Suite de Verificación de Integración: PRO CAM Seguridad Web 2.2
 * Valida:
 * 1. Modelos relacionales Mongoose (Unit, Category, Product, Campaign, Visit, Prospect, Quotation).
 * 2. Acceso público a Catálogo de Soluciones sin token JWT.
 * 3. Captura y atribución de campañas QR (persistente en sesión).
 * 4. Creación de Prospecto + Cotización correlativa (COT-YYYY-XXXX).
 * 5. Servicio de correo tolerante a fallos.
 */

import mongoose from 'mongoose';
import dotenv from 'dotenv';
dotenv.config();

import Unit from './models/Unit.js';
import Category from './models/Category.js';
import Product from './models/Product.js';
import Campaign from './models/Campaign.js';
import Visit from './models/Visit.js';
import Prospect from './models/Prospect.js';
import Quotation from './models/Quotation.js';
import { seedInitialData } from './config/seedData.js';
import { createQuotation } from './controllers/quotationController.js';

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;

function assert(condition, message) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✅ PASS: ${message}`);
  } else {
    failedTests++;
    console.error(`  ❌ FAIL: ${message}`);
  }
}

async function runTestSuite() {
  console.log('\n======================================================');
  console.log('🧪 VERIFICACIÓN TÉCNICA: PRO CAM SEGURIDAD WEB 2.0 (COTIZADOR)');
  console.log('======================================================\n');

  try {
    console.log('🔌 1. Conectando a MongoDB Atlas...');
    await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 8000,
      socketTimeoutMS: 45000,
    });
    assert(mongoose.connection.readyState === 1, 'Conexión a MongoDB Atlas establecida');

    console.log('\n🌱 2. Verificación de Inicialización de Datos (Seed)...');
    await seedInitialData();

    const unitsCount = await Unit.countDocuments();
    assert(unitsCount >= 4, `Unidades de medida cargadas (${unitsCount})`);

    const catCount = await Category.countDocuments();
    assert(catCount >= 4, `Categorías de seguridad cargadas (${catCount})`);

    const campaignsCount = await Campaign.countDocuments();
    assert(campaignsCount >= 5, `Campañas QR configuradas (${campaignsCount})`);

    const prodsCount = await Product.countDocuments();
    assert(prodsCount >= 8, `Soluciones de seguridad cargadas (${prodsCount})`);

    console.log('\n📍 3. Verificación de Tracking QR y Atribución...');
    const testSessionId = 'test_sess_' + Date.now();
    const testCampaign = 'QR-CCTV';

    const testVisit = new Visit({
      sessionId: testSessionId,
      campaignRef: testCampaign,
      dispositivo: 'Mobile',
      landingPage: '/productos.html',
      referrer: 'https://instagram.com'
    });
    await testVisit.save();
    assert(testVisit._id !== null, 'Visita registrada con sesión y campaña atribuida');

    console.log('\n📝 4. Verificación del Flujo de Cotización y Prospecto...');
    // Simular llamada al controlador createQuotation
    const mockReq = {
      body: {
        nombre: 'Cliente Test Auditoría',
        empresa: 'Industrias Quilmes S.A.',
        email: `test_auditoria_${Date.now()}@procamseguridad.com.ar`,
        telefono: '1123456789',
        localidad: 'Quilmes',
        observaciones: 'Requerimos 4 cámaras y cerco de 30m',
        campaignRef: testCampaign,
        sessionId: testSessionId,
        items: [
          {
            nombre: 'PRO CAM CCTV Hogar - Avanzada',
            segmento: 'Hogar',
            nivel: 'Avanzada',
            unidad: 'Kit',
            cantidad: 1
          },
          {
            nombre: 'PRO CAM Perimetral - Cerco Eléctrico Homologado',
            segmento: 'Hogar',
            nivel: 'Esencial',
            unidad: 'Metro lineal',
            cantidad: 30
          }
        ]
      }
    };

    let responseData = null;
    let statusCode = 200;
    const mockRes = {
      status: (code) => { statusCode = code; return mockRes; },
      json: (data) => { responseData = data; return mockRes; }
    };

    await createQuotation(mockReq, mockRes);

    assert(statusCode === 201, 'Endpoint de cotización responde con status HTTP 201 Created');
    assert(responseData?.success === true, 'Respuesta indica éxito en la solicitud');
    assert(Boolean(responseData?.quotationNumber), `Número correlativo generado: ${responseData?.quotationNumber}`);
    assert(responseData?.confirmationText.includes('asesor técnico comercial'), 'Texto de confirmación oficial devuelto');

    // Verificar en BD
    const createdProspect = await Prospect.findOne({ email: mockReq.body.email });
    assert(createdProspect !== null, 'Prospecto creado y almacenado correctamente en MongoDB');
    assert(createdProspect?.campaignRef === testCampaign, 'Prospecto conserva la campaña QR de origen');

    const createdQuote = await Quotation.findOne({ numero: responseData.quotationNumber });
    assert(createdQuote !== null, 'Cotización creada y vinculada con el prospecto');
    assert(createdQuote?.items.length === 2, 'Los 2 ítems y cantidades quedaron asociados a la cotización');
    assert(createdQuote?.estado === 'ABIERTO', 'Estado inicial de la cotización es ABIERTO');

    // Limpieza de datos de prueba
    await Visit.deleteOne({ _id: testVisit._id });
    if (createdQuote) await Quotation.deleteOne({ _id: createdQuote._id });
    if (createdProspect) await Prospect.deleteOne({ _id: createdProspect._id });
    console.log('🧹 Limpieza de registros de prueba completada.');

  } catch (error) {
    assert(false, `Error durante la prueba de integración: ${error.message}`);
  } finally {
    await mongoose.disconnect();
    console.log('\n======================================================');
    console.log(`📊 RESULTADOS: ${passedTests}/${totalTests} pruebas superadas.`);
    if (failedTests === 0) {
      console.log('🎉 TODAS LAS PRUEBAS DEL COTIZADOR Y ARQUITECTURA COMPLETADAS CON ÉXITO.');
    } else {
      console.log(`⚠️ Fallaron ${failedTests} pruebas.`);
    }
    console.log('======================================================\n');
  }
}

runTestSuite();
