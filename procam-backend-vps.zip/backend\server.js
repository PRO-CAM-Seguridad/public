import mongoose from 'mongoose';
import dotenv from 'dotenv';
dotenv.config();
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import path from 'path';
import { fileURLToPath } from 'url';

import authRoutes      from './routes/authRoutes.js';
import productRoutes   from './routes/productRoutes.js';
import categoryRoutes  from './routes/categoryRoutes.js';
import unitRoutes      from './routes/unitRoutes.js';
import quotationRoutes from './routes/quotationRoutes.js';
import prospectRoutes  from './routes/prospectRoutes.js';
import campaignRoutes  from './routes/campaignRoutes.js';
import promotionRoutes from './routes/promotionRoutes.js';
import analyticsRoutes from './routes/analyticsRoutes.js';
import reviewRoutes    from './routes/reviewRoutes.js';

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── __dirname (ESM) ─────────────────────────────────────
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

// ─── CORS ────────────────────────────────────────────────
const allowedOrigins = [
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'http://localhost:5500',
  'http://127.0.0.1:5500',
  'https://procamseguridad.com.ar',
  'https://www.procamseguridad.com.ar',
  process.env.FRONTEND_URL,
].filter(Boolean);

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || origin === 'null' || allowedOrigins.includes(origin) || origin.startsWith('http://localhost') || origin.startsWith('http://127.0.0.1') || origin.endsWith('.vercel.app')) {
      return cb(null, true);
    }
    return cb(null, true); // Permitir peticiones en producción y desarrollo
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}));

// ─── Security & Logging ──────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc:  ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
      styleSrc:   ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com", "https://fonts.googleapis.com"],
      fontSrc:    ["'self'", "https://cdnjs.cloudflare.com", "https://fonts.gstatic.com"],
      imgSrc:     ["'self'", "data:", "https:", "blob:"],
      connectSrc: ["'self'", "https:", "http://localhost:*"],
    }
  }
}));

if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// ─── Body Parsing ────────────────────────────────────────
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// ─── Serve Frontend Static Files ─────────────────────────
const frontendPath = path.join(__dirname, '../frontend');
app.use(express.static(frontendPath, {
  index: 'index.html',
  extensions: ['html'],
}));

// ─── API Routes ──────────────────────────────────────────
// Soporte directo y con prefijo /api/ para máxima compatibilidad
const registerEndpoints = (prefix = '') => {
  app.use(`${prefix}/auth`,        authRoutes);
  app.use(`${prefix}/products`,    productRoutes);
  app.use(`${prefix}/categories`,  categoryRoutes);
  app.use(`${prefix}/units`,       unitRoutes);
  app.use(`${prefix}/quotations`,  quotationRoutes);
  app.use(`${prefix}/prospects`,   prospectRoutes);
  app.use(`${prefix}/campaigns`,   campaignRoutes);
  app.use(`${prefix}/promotions`,  promotionRoutes);
  app.use(`${prefix}/analytics`,   analyticsRoutes);
  app.use(`${prefix}/reviews`,     reviewRoutes);
};

registerEndpoints('');
registerEndpoints('/api');

// ─── Health check ────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    platform: 'PRO CAM Seguridad Web 2.2',
    env: process.env.NODE_ENV || 'development',
    ts: new Date().toISOString(),
  });
});

// ─── Redirecciones 301 de URLs obsoletas (Web 1.0) ─────────
app.get([
  '/productos', '/productos.html',
  '/products', '/products.html',
  '/cart', '/cart.html',
  '/failure', '/failure.html',
  '/pending', '/pending.html',
  '/success', '/success.html',
  '/login', '/login.html',
  '/registro', '/registro.html',
  '/perfil', '/perfil.html'
], (req, res) => {
  res.redirect(301, '/soluciones.html');
});

// ─── SPA Fallback (HTML5 history mode) ───────────────────
const apiPrefixes = [
  '/api', '/auth', '/products', '/categories', '/units',
  '/quotations', '/prospects', '/campaigns', '/promotions', '/analytics'
];

app.get('*', (req, res) => {
  if (apiPrefixes.some(p => req.path.startsWith(p))) {
    return res.status(404).json({ success: false, message: 'Endpoint no encontrado' });
  }
  const htmlFile = path.join(frontendPath, req.path.endsWith('.html') ? req.path : req.path + '.html');
  res.sendFile(htmlFile, (err) => {
    if (err) res.sendFile(path.join(frontendPath, 'index.html'));
  });
});

// ─── Global Error Handler ────────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌ Error no controlado:', err.message);
  res.status(err.status || 500).json({
    success: false,
    message: process.env.NODE_ENV === 'production' ? 'Error interno del servidor' : err.message,
  });
});

// ─── DB + Start ──────────────────────────────────────────
mongoose.connect(process.env.MONGO_URI, {
  serverSelectionTimeoutMS: 8000,
  socketTimeoutMS: 45000,
})
.then(async () => {
  console.log('✅ Conectado a MongoDB Atlas (PRO CAM)');
  try {
    const { seedInitialData } = await import('./config/seedData.js');
    await seedInitialData();
  } catch (seedErr) {
    console.warn('⚠️ Seeding omitido o con advertencia:', seedErr.message);
  }
  app.listen(PORT, () => {
    console.log(`✅ Servidor PRO CAM Web 2.0 corriendo en http://localhost:${PORT}`);
    console.log(`📁 Frontend: ${frontendPath}`);
    console.log(`🌍 Entorno: ${process.env.NODE_ENV || 'development'}`);
  });
})
.catch((error) => {
  console.error('❌ Error conectando a MongoDB:', error.message);
  process.exit(1);
});
