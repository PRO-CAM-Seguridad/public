const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    if (!process.env.MONGO_URI) {
      console.warn('⚠️ MONGO_URI no está configurada en .env.');
      return;
    }
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('✅ MongoDB conectado');

    // Inicializar usuario admin por default
    const seedAdmin = require('./seedAdmin');
    await seedAdmin();
  } catch (err) {
    console.error('❌ Error de conexión a MongoDB:', err.message);
  }
};

module.exports = connectDB;
