import express from 'express';
import {
  getCategories,
  getCategoryById,
  createCategory,
  updateCategory,
  deleteCategory
} from '../controllers/categoryController.js';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// 📋 Obtener todas las categorías (PÚBLICO para catálogo y cotizador)
router.get('/', getCategories);

// 🔎 Obtener una categoría por ID (PÚBLICO)
router.get('/:id', getCategoryById);

// ➕ Crear categoría (solo admin)
router.post('/', authMiddleware, adminMiddleware, createCategory);

// ✏️ Actualizar categoría (solo admin)
router.put('/:id', authMiddleware, adminMiddleware, updateCategory);

// 🗑️ Eliminar categoría (solo admin)
router.delete('/:id', authMiddleware, adminMiddleware, deleteCategory);

export default router;
