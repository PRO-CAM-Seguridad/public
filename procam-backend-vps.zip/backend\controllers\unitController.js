import Unit from '../models/Unit.js';

/**
 * 📋 Listar todas las unidades (Público)
 */
export async function getUnits(req, res) {
  try {
    const units = await Unit.find({ activo: true }).sort({ nombre: 1 });
    res.json({ success: true, count: units.length, units });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener unidades', error: error.message });
  }
}

/**
 * ➕ Crear una unidad (Solo Admin)
 */
export async function createUnit(req, res) {
  try {
    const { nombre, abreviatura } = req.body;
    if (!nombre || !abreviatura) {
      return res.status(400).json({ success: false, message: 'Nombre y abreviatura son requeridos' });
    }

    const unit = new Unit({ nombre: nombre.trim(), abreviatura: abreviatura.trim() });
    await unit.save();
    res.status(201).json({ success: true, message: 'Unidad creada con éxito', unit });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al crear unidad', error: error.message });
  }
}

/**
 * ✏️ Actualizar una unidad (Solo Admin)
 */
export async function updateUnit(req, res) {
  try {
    const unit = await Unit.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!unit) return res.status(404).json({ success: false, message: 'Unidad no encontrada' });
    res.json({ success: true, message: 'Unidad actualizada', unit });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al actualizar unidad', error: error.message });
  }
}

/**
 * 🗑️ Eliminar una unidad (Solo Admin)
 */
export async function deleteUnit(req, res) {
  try {
    const unit = await Unit.findByIdAndDelete(req.params.id);
    if (!unit) return res.status(404).json({ success: false, message: 'Unidad no encontrada' });
    res.json({ success: true, message: 'Unidad eliminada' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al eliminar unidad', error: error.message });
  }
}
