import mongoose from 'mongoose';

const deviceSessionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: false },
  deviceType: { type: String, required: true }, // Ej: "Mobile", "Desktop", "Tablet"
  browser: String, // Ej: "Chrome", "Safari"
  os: String,      // Ej: "Windows", "Android"
  ip: String,
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('DeviceSession', deviceSessionSchema);
