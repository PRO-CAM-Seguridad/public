
import User from '../models/User.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { validationResult } from 'express-validator';

// =====================================================
// GENERAR JWT
// =====================================================

const generateToken = (user) => {
  const payload = typeof user === 'object' && user._id
    ? { id: user._id, role: user.role, nombre: user.nombre, email: user.email }
    : { id: user };
  return jwt.sign(
    payload,
    process.env.JWT_SECRET || 'secretkey',
    {
      expiresIn: process.env.JWT_EXPIRES || '7d'
    }
  );
};

// =====================================================
// GENERAR CÓDIGO DE VERIFICACIÓN
// =====================================================

const generateVerificationCode = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// =====================================================
// REGISTRO
// =====================================================

export async function register(req, res) {

  try {

    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    const {
      nombre,
      email,
      password,
      tipoCliente,
      telefono,
      tipoDocumento,
      numeroDocumento,
      fechaNacimiento,
      direccion,
      localidad,
      codigoPostal
    } = req.body;

    // -----------------------------
    // Datos obligatorios
    // -----------------------------

    if (
      !nombre ||
      !email ||
      !password ||
      !tipoCliente ||
      !telefono ||
      !tipoDocumento ||
      !numeroDocumento
    ) {
      return res.status(400).json({
        success: false,
        message: 'Faltan datos obligatorios'
      });
    }

    // -----------------------------
    // Persona / Empresa
    // -----------------------------

    if (
      tipoCliente === 'persona' &&
      tipoDocumento !== 'DNI'
    ) {
      return res.status(400).json({
        success: false,
        message: 'Una persona debe registrarse con DNI'
      });
    }

    if (
      tipoCliente === 'empresa' &&
      tipoDocumento !== 'CUIT'
    ) {
      return res.status(400).json({
        success: false,
        message: 'Una empresa debe registrarse con CUIT'
      });
    }

    // -----------------------------
    // Fecha de nacimiento
    // -----------------------------

    if (
      tipoCliente === 'persona' &&
      !fechaNacimiento
    ) {
      return res.status(400).json({
        success: false,
        message: 'La fecha de nacimiento es obligatoria'
      });
    }

    // -----------------------------
    // Normalizar email
    // -----------------------------

    const emailNormalizado =
      email.toLowerCase().trim();

    // -----------------------------
    // Buscar email existente
    // -----------------------------

    const existingUser = await User.findOne({
      email: emailNormalizado
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'El usuario ya existe'
      });
    }

    // -----------------------------
    // Buscar DNI/CUIT existente
    // -----------------------------

    const existingDocument = await User.findOne({
      numeroDocumento: numeroDocumento.trim()
    });

    if (existingDocument) {
      return res.status(400).json({
        success: false,
        message: 'El DNI/CUIT ya se encuentra registrado'
      });
    }

    // -----------------------------
    // Encriptar contraseña
    // -----------------------------

    const hashedPassword =
      await bcrypt.hash(password, 10);

    // -----------------------------
    // Código de verificación
    // -----------------------------

    const verificationCode =
      generateVerificationCode();

    const verificationExpires =
      new Date(Date.now() + 2 * 60 * 60 * 1000);

    // -----------------------------
    // Crear usuario
    // -----------------------------

    const user = new User({

      nombre: nombre.trim(),

      email: emailNormalizado,

      password: hashedPassword,

      tipoCliente,

      telefono: telefono.trim(),

      tipoDocumento,

      numeroDocumento:
        numeroDocumento.trim(),

      fechaNacimiento:
        tipoCliente === 'persona'
          ? fechaNacimiento
          : undefined,

      direccion:
        direccion
          ? direccion.trim()
          : undefined,

      localidad:
        localidad
          ? localidad.trim()
          : undefined,

      codigoPostal:
        codigoPostal
          ? codigoPostal.trim()
          : undefined,

      verified: false,

      verificationToken:
        verificationCode,

      verificationExpires,

      // El usuario NO puede elegir su rol.
      role: 'user'

    });

    await user.save();

    // -----------------------------
    // Código visible durante desarrollo
    // -----------------------------

    console.log(
      '🔐 Código de verificación:',
      verificationCode
    );

    console.log(
      '⏱️ Código válido hasta:',
      verificationExpires
    );

    return res.status(201).json({

      success: true,

      message:
        'Usuario registrado. Verifica tu cuenta.',

      verificationRequired: true

    });

  } catch (err) {

    console.error(
      '❌ Error en el registro:',
      err
    );

    return res.status(500).json({

      success: false,

      message: 'Error en el registro',

      error: err.message

    });

  }

}

// =====================================================
// LOGIN
// =====================================================

export async function login(req, res) {

  try {

    const { email, password } = req.body;

    const emailNormalizado =
      email?.toLowerCase().trim();

    const user = await User.findOne({
      email: emailNormalizado
    });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    // -----------------------------
    // Cuenta verificada
    // -----------------------------

    if (!user.verified) {
      return res.status(400).json({
        success: false,
        message: 'Cuenta no verificada'
      });
    }

    // -----------------------------
    // Contraseña
    // -----------------------------

    const isMatch =
      await bcrypt.compare(
        password,
        user.password
      );

    if (!isMatch) {
      return res.status(400).json({
        success: false,
        message: 'Contraseña incorrecta'
      });
    }

    // -----------------------------
    // JWT
    // -----------------------------

    const token =
      generateToken(user);

    // -----------------------------
    // Respuesta
    // -----------------------------

    return res.json({

      success: true,

      message: 'Login exitoso',

      token,

      user: {

        id: user._id,

        nombre: user.nombre,

        email: user.email,

        tipoCliente: user.tipoCliente,

        telefono: user.telefono,

        tipoDocumento:
          user.tipoDocumento,

        numeroDocumento:
          user.numeroDocumento,

        fechaNacimiento:
          user.fechaNacimiento,

        direccion:
          user.direccion,

        localidad:
          user.localidad,

        codigoPostal:
          user.codigoPostal,

        role:
          user.role

      }

    });

  } catch (err) {

    console.error(
      '❌ Error en el login:',
      err
    );

    return res.status(500).json({

      success: false,

      message: 'Error en el login',

      error: err.message

    });

  }

}

// =====================================================
// VERIFICAR EMAIL
// =====================================================

export async function verifyEmail(req, res) {

  try {

    const { email, code } = req.body;

    if (!email || !code) {

      return res.status(400).json({

        success: false,

        message:
          'Email y código son obligatorios'

      });

    }

    const user = await User.findOne({

      email:
        email.toLowerCase().trim()

    });

    if (!user) {

      return res.status(400).json({

        success: false,

        message:
          'Usuario no encontrado'

      });

    }

    if (user.verified) {

      return res.status(400).json({

        success: false,

        message:
          'La cuenta ya está verificada'

      });

    }

    // -----------------------------
    // Expiración
    // -----------------------------

    if (
      !user.verificationExpires ||
      user.verificationExpires < new Date()
    ) {

      return res.status(400).json({

        success: false,

        message:
          'El código de verificación ha expirado'

      });

    }

    // -----------------------------
    // Código
    // -----------------------------

    if (
      user.verificationToken !==
      code.toString().trim()
    ) {

      return res.status(400).json({

        success: false,

        message:
          'Código de verificación incorrecto'

      });

    }

    // -----------------------------
    // Activar cuenta
    // -----------------------------

    user.verified = true;

    user.verificationToken = undefined;

    user.verificationExpires = undefined;

    await user.save();

    return res.json({

      success: true,

      message:
        'Cuenta verificada con éxito'

    });

  } catch (err) {

    console.error(
      '❌ Error verificando la cuenta:',
      err
    );

    return res.status(500).json({

      success: false,

      message:
        'Error verificando la cuenta',

      error: err.message

    });

  }

}

// =====================================================
// GESTIÓN DE EQUIPO COMERCIAL / ASESORES DE VENTAS
// =====================================================

export async function createSalesAgent(req, res) {
  try {
    const { nombre, email, password, telefono, cargo, firmaDigital, fotoPerfil } = req.body;

    if (!nombre || !email || !password) {
      return res.status(400).json({ success: false, message: 'Nombre, email y contraseña son obligatorios' });
    }

    const emailNorm = email.toLowerCase().trim();
    const existing = await User.findOne({ email: emailNorm });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Ya existe un usuario con este correo electrónico.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const agent = new User({
      nombre: nombre.trim(),
      email: emailNorm,
      password: hashedPassword,
      telefono: telefono?.trim() || '1123940806',
      tipoCliente: 'persona',
      tipoDocumento: 'DNI',
      numeroDocumento: '00000000',
      role: 'ventas',
      cargo: cargo?.trim() || 'Asesor Técnico Comercial',
      fotoPerfil: fotoPerfil?.trim() || '',
      firmaDigital: firmaDigital?.trim() || `${nombre.trim()} — Asesor Técnico Comercial | PRO CAM Seguridad`,
      verified: true
    });

    await agent.save();

    res.status(201).json({
      success: true,
      message: 'Asesor comercial creado con éxito',
      agent: {
        id: agent._id,
        nombre: agent.nombre,
        email: agent.email,
        telefono: agent.telefono,
        cargo: agent.cargo,
        fotoPerfil: agent.fotoPerfil,
        firmaDigital: agent.firmaDigital,
        role: agent.role
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al crear asesor', error: err.message });
  }
}

export async function getSalesAgents(req, res) {
  try {
    const agents = await User.find({ role: { $in: ['ventas', 'admin'] } })
      .select('nombre email telefono cargo fotoPerfil firmaDigital role fechaRegistro')
      .sort({ fechaRegistro: -1 });

    res.json({ success: true, count: agents.length, agents });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener equipo de ventas', error: err.message });
  }
}

export async function deleteSalesAgent(req, res) {
  try {
    const agent = await User.findById(req.params.id);
    if (!agent) {
      return res.status(404).json({ success: false, message: 'Usuario no encontrado' });
    }
    if (agent.role === 'root') {
      return res.status(403).json({ success: false, message: 'No es posible eliminar el usuario root.' });
    }
    await User.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Usuario asesor eliminado con éxito.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al eliminar asesor', error: err.message });
  }
}

/**
 * ✏️ Actualizar datos de un Asesor Comercial (Solo Admin)
 */
export async function updateSalesAgent(req, res) {
  try {
    const { nombre, email, telefono, cargo, firmaDigital, fotoPerfil, password } = req.body;
    const updateData = {};
    if (nombre) updateData.nombre = nombre.trim();
    if (email) updateData.email = email.toLowerCase().trim();
    if (telefono) updateData.telefono = telefono.trim();
    if (cargo) updateData.cargo = cargo.trim();
    if (fotoPerfil !== undefined) updateData.fotoPerfil = fotoPerfil.trim();
    if (firmaDigital !== undefined) updateData.firmaDigital = firmaDigital.trim();
    if (password && password.trim()) {
      updateData.password = await bcrypt.hash(password.trim(), 10);
    }

    const agent = await User.findByIdAndUpdate(req.params.id, updateData, { new: true });
    if (!agent) return res.status(404).json({ success: false, message: 'Asesor no encontrado' });
    res.json({ success: true, message: 'Asesor actualizado con éxito', agent });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al actualizar asesor', error: err.message });
  }
}

/**
 * 🔒 Cambiar Contraseña validando contra correo registrado (Autenticado)
 */
export async function changePassword(req, res) {
  try {
    const { email, currentPassword, newPassword, confirmPassword } = req.body;

    if (!email || !currentPassword || !newPassword) {
      return res.status(400).json({ success: false, message: 'Todos los campos son obligatorios.' });
    }

    if (newPassword !== confirmPassword) {
      return res.status(400).json({ success: false, message: 'La nueva contraseña y su confirmación no coinciden.' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ success: false, message: 'La contraseña debe tener al menos 6 caracteres.' });
    }

    // Buscar usuario por ID autenticado o por email
    const userId = req.user?.id || req.user?._id;
    let user = null;
    if (userId) {
      user = await User.findById(userId);
    }
    if (!user) {
      user = await User.findOne({ email: email.toLowerCase().trim() });
    }

    if (!user) {
      return res.status(404).json({ success: false, message: 'Usuario no encontrado.' });
    }

    // Validar que el correo ingresado coincida exactamente con el correo registrado
    if (user.email.toLowerCase().trim() !== email.toLowerCase().trim()) {
      return res.status(400).json({ success: false, message: 'El correo electrónico no coincide con la cuenta registrada.' });
    }

    // Validar contraseña actual
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      return res.status(400).json({ success: false, message: 'La contraseña actual ingresada es incorrecta.' });
    }

    user.password = await bcrypt.hash(newPassword, 10);
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    res.json({ success: true, message: 'Contraseña actualizada correctamente.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al cambiar contraseña', error: err.message });
  }
}

/**
 * 📧 Solicitar Código de Recuperación de Contraseña
 */
export async function requestPasswordReset(req, res) {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: 'El correo registrado es requerido.' });
    }

    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user) {
      return res.status(404).json({ success: false, message: 'No se encontró ninguna cuenta con ese correo electrónico registrado.' });
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    user.resetPasswordToken = code;
    user.resetPasswordExpires = new Date(Date.now() + 30 * 60 * 1000); // 30 minutos
    await user.save();

    console.log(`🔐 [PRO CAM] Código de recuperación para ${user.email}: ${code}`);

    res.json({
      success: true,
      message: `Código de recuperación generado y enviado a ${user.email}. Válido por 30 minutos.`,
      recoveryCode: code // Facilitar pruebas locales directas
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al generar código de recuperación', error: err.message });
  }
}

/**
 * 🔑 Restablecer Contraseña con Código de Verificación
 */
export async function resetPasswordWithCode(req, res) {
  try {
    const { email, code, newPassword, confirmPassword } = req.body;

    if (!email || !code || !newPassword) {
      return res.status(400).json({ success: false, message: 'Email, código y nueva contraseña requeridos.' });
    }

    if (confirmPassword && newPassword !== confirmPassword) {
      return res.status(400).json({ success: false, message: 'Las contraseñas no coinciden.' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ success: false, message: 'La contraseña debe tener al menos 6 caracteres.' });
    }

    const user = await User.findOne({
      email: email.toLowerCase().trim(),
      resetPasswordToken: code.trim(),
      resetPasswordExpires: { $gt: new Date() }
    });

    if (!user) {
      return res.status(400).json({ success: false, message: 'Código de recuperación inválido o expirado.' });
    }

    user.password = await bcrypt.hash(newPassword, 10);
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    res.json({ success: true, message: 'Contraseña restablecida con éxito. Ya puedes iniciar sesión con tu nueva clave.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al restablecer contraseña', error: err.message });
  }
}

