import mongoose from 'mongoose';

const visitSchema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  campaignRef: { type: String, default: 'QR-WEB', uppercase: true, trim: true, index: true },
  ip: { type: String, default: 'Desconocida' },
  dispositivo: { type: String, default: 'Desconocido' }, // Mobile, Desktop, Tablet
  navegador: { type: String },
  os: { type: String },
  landingPage: { type: String },
  referrer: { type: String },
  zona: { type: String, trim: true, default: '' },
  solucion: { type: String, trim: true, default: '' },
  canal: { type: String, trim: true, default: '' },
  pieza: { type: String, trim: true, default: '' },
  fechaHora: { type: Date, default: Date.now, index: true }
});

export default mongoose.model('Visit', visitSchema);
