import express from 'express';
import {
  createQuotation,
  getAllQuotations,
  getQuotationById,
  updateQuotationState,
  replyQuotation,
  saveProposal,
  sendProposalEmail
} from '../controllers/quotationController.js';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// 📝 Crear solicitud de cotización (PÚBLICO - Visitantes)
router.post('/', createQuotation);

// 📋 Listar cotizaciones (Solo Admin/Ventas)
router.get('/', authMiddleware, adminMiddleware, getAllQuotations);

// 🔎 Ver detalle de cotización (Solo Admin/Ventas)
router.get('/:id', authMiddleware, adminMiddleware, getQuotationById);

// ✏️ Actualizar estado comercial / notas (Solo Admin/Ventas)
router.put('/:id/state', authMiddleware, adminMiddleware, updateQuotationState);

// 🛠️ Modelar Propuesta Técnica Comercial Online
router.put('/:id/proposal', authMiddleware, adminMiddleware, saveProposal);

// 📧 Enviar Propuesta Formal por Email
router.post('/:id/send-email', authMiddleware, adminMiddleware, sendProposalEmail);

// ✉️ Responder cotización / Ticket comercial con Frame Institucional y Firma Digital
router.post('/:id/reply', authMiddleware, adminMiddleware, replyQuotation);

export default router;
