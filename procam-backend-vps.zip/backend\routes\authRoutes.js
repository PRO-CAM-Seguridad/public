import express from 'express';

import {
  register,
  login,
  verifyEmail,
  createSalesAgent,
  getSalesAgents,
  updateSalesAgent,
  deleteSalesAgent,
  changePassword,
  requestPasswordReset,
  resetPasswordWithCode
} from '../controllers/authController.js';

import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// Registro de usuario
router.post('/register', register);

// Login de usuario
router.post('/login', login);

// Verificacion de email mediante codigo de 6 digitos
router.post('/verify', verifyEmail);

// 🔒 Cambiar Contraseña (Autenticado en Settings)
router.post('/change-password', authMiddleware, changePassword);

// 📧 Recuperación de Contraseña con código al correo
router.post('/request-reset', requestPasswordReset);
router.post('/reset-password', resetPasswordWithCode);

// Perfil protegido
router.get('/profile', authMiddleware, (req, res) => {
  res.json({
    success: true,
    user: req.user
  });
});

// 👔 Gestión de Equipo Comercial / Asesores (Solo Admin/Root/Ventas)
router.get('/sales-agents', authMiddleware, adminMiddleware, getSalesAgents);
router.post('/sales-agent', authMiddleware, adminMiddleware, createSalesAgent);
router.put('/sales-agent/:id', authMiddleware, adminMiddleware, updateSalesAgent);
router.delete('/sales-agent/:id', authMiddleware, adminMiddleware, deleteSalesAgent);

export default router;