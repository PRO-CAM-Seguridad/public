import mongoose from 'mongoose';

const promotionSchema = new mongoose.Schema({
  nombre: { type: String, required: true, trim: true }, // Ej: "Promo Primavera"
  codigo: { type: String, trim: true, uppercase: true }, // Cupón opcional
  tipoDescuento: {
    type: String,
    enum: ['porcentaje', 'monto_fijo_ars', 'monto_fijo_usd', 'por_cantidad'],
    required: true
  },
  valor: { type: Number, required: true }, // % o monto numérico
  condicionCantidad: { type: Number, default: 0 }, // Ej: > a X cantidad de unidades
  porcentajeCantidad: { type: Number, default: 0 }, // % de descuento si supera la cantidad
  activo: { type: Boolean, default: true },
  descripcion: { type: String, trim: true },
  validoHasta: { type: Date },
  fechaCreacion: { type: Date, default: Date.now }
});

export default mongoose.model('Promotion', promotionSchema);
