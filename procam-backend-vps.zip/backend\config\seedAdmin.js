const User = require('../models/User');
const bcrypt = require('bcryptjs');

/**
 * Seeding de usuarios institucionales:
 * 1. Root: rootprocam (Rol: root, segurización de API)
 * 2. Admin: adminprocam (Rol: admin, ABM productos/categorías/promociones)
 */
async function seedAdminUser() {
  try {
    // 1. Usuario Root (Seguridad de API)
    const rootEmail = 'root@procamseguridad.com.ar';
    let rootUser = await User.findOne({
      $or: [
        { email: rootEmail },
        { email: 'rootprocam' },
        { nombre: 'rootprocam' }
      ]
    });

    if (!rootUser) {
      const hashedRootPass = await bcrypt.hash('root2026procam!', 10);
      rootUser = new User({
        nombre: 'rootprocam',
        email: rootEmail,
        password: hashedRootPass,
        role: 'root',
        verified: true
      });
      await rootUser.save();
      console.log('🛡️ Usuario ROOT creado con éxito: rootprocam (email: root@procamseguridad.com.ar)');
    } else {
      if (rootUser.role !== 'root') {
        rootUser.role = 'root';
        await rootUser.save();
      }
    }

    // 2. Usuario Admin (Gestión ABM, Categorías y Promociones)
    const adminEmail = 'adminprocam@procamseguridad.com.ar';
    let adminUser = await User.findOne({
      $or: [
        { email: adminEmail },
        { email: 'adminprocam' },
        { nombre: 'adminprocam' }
      ]
    });

    if (!adminUser) {
      const hashedAdminPass = await bcrypt.hash('173394', 10);
      adminUser = new User({
        nombre: 'adminprocam',
        email: adminEmail,
        password: hashedAdminPass,
        role: 'admin',
        verified: true
      });
      await adminUser.save();
      console.log('👑 Usuario ADMIN creado con éxito: adminprocam (password por default: 173394)');
    } else {
      let needsSave = false;
      if (adminUser.role !== 'admin' && adminUser.role !== 'root') {
        adminUser.role = 'admin';
        needsSave = true;
      }
      if (!adminUser.verified) {
        adminUser.verified = true;
        needsSave = true;
      }
      if (needsSave) {
        await adminUser.save();
      }
    }
  } catch (err) {
    console.warn('⚠️ No se pudieron inicializar los usuarios root y admin:', err.message);
  }
}

module.exports = seedAdminUser;
