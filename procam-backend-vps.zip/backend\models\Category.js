import mongoose from 'mongoose';

const categorySchema = new mongoose.Schema({
  nombre: { type: String, required: true, unique: true, trim: true },
  descripcion: { type: String, trim: true },
  visible: { type: Boolean, default: true }, // 👁️ Control para visualizar u ocultar categoría
  fechaCreacion: { type: Date, default: Date.now }
});

export default mongoose.model('Category', categorySchema);
