import mongoose from 'mongoose';

const quotationItemSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
  nombre: { type: String, required: true },
  segmento: { type: String, enum: ['Hogar', 'Empresas', 'Smart'] },
  nivel: { type: String },
  categoria: { type: String },
  unidad: { type: String, default: 'Unidad' },
  cantidad: { type: Number, required: true, min: 1, default: 1 },
  precioUnitario: { type: Number, default: 0 },
  subtotal: { type: Number, default: 0 },
  notas: { type: String }
}, { _id: false });

const quotationSchema = new mongoose.Schema({
  numero: { type: String, unique: true, index: true }, // Ej: "COT-2026-0001"
  prospect: { type: mongoose.Schema.Types.ObjectId, ref: 'Prospect', required: true, index: true },
  items: [quotationItemSchema],
  subtotal: { type: Number, default: 0 },
  descuentoPorcentaje: { type: Number, default: 0 },
  descuentoMonto: { type: Number, default: 0 },
  recargoPorcentaje: { type: Number, default: 0 },
  recargoMonto: { type: Number, default: 0 },
  total: { type: Number, default: 0 },
  medioPago: {
    type: String,
    enum: [
      'Efectivo', 'Transferencia Bancaria', 'Mercado Pago', 'A convenir',
      'efectivo', 'transferencia', 'mercadopago', 'a_convenir'
    ],
    default: 'A convenir'
  },
  mercadoPagoLink: { type: String, default: '' },
  promocion: { type: String, default: '' },
  propuestaTecnica: { type: String, default: '' },
  observaciones: { type: String, trim: true },
  campaignRef: { type: String, default: 'QR-WEB', uppercase: true, trim: true, index: true },
  sessionId: { type: String, index: true },
  estado: {
    type: String,
    enum: ['ABIERTO', 'EN TRATAMIENTO', 'COTIZADA', 'ACEPTADA', 'RECHAZADA', 'CERRADO'],
    default: 'ABIERTO',
    index: true
  },
  notasInternas: { type: String },
  asesorAsignado: {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    nombre: { type: String, default: 'Equipo Comercial PRO CAM' },
    cargo: { type: String, default: 'Asesor Técnico Comercial' },
    telefono: { type: String, default: '+54 11 2394 0806' },
    email: { type: String, default: 'ventas@procamseguridad.com.ar' },
    firmaDigital: { type: String, default: '' },
    fotoPerfil: { type: String, default: '' }
  },
  respuestas: [
    {
      fecha: { type: Date, default: Date.now },
      asesorNombre: String,
      asesorCargo: String,
      mensaje: String,
      precioPresupuestado: String,
      validezOferta: String,
      medioPago: String,
      mercadoPagoLink: String,
      metodoEnvio: { type: String, enum: ['sistema', 'whatsapp', 'email'], default: 'sistema' }
    }
  ],
  historial: [
    {
      fecha: { type: Date, default: Date.now },
      estadoAnterior: String,
      estadoNuevo: String,
      usuario: String,
      comentario: String
    }
  ],
  fechaCreacion: { type: Date, default: Date.now, index: true }
});

export default mongoose.model('Quotation', quotationSchema);
