import Category from '../models/Category.js';

// 📋 Obtener todas las categorías
export async function getCategories(req, res) {
  try {
    const categories = await Category.find();
    res.json({ success: true, categories });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener categorías', error: err.message });
  }
}

// 🔎 Obtener categoría por ID
export async function getCategoryById(req, res) {
  try {
    const category = await Category.findById(req.params.id);
    if (!category) return res.status(404).json({ success: false, message: 'Categoría no encontrada' });
    res.json({ success: true, category });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al obtener categoría', error: err.message });
  }
}

// ➕ Crear nueva categoría
export async function createCategory(req, res) {
  try {
    const category = new Category(req.body);
    await category.save();
    res.status(201).json({ success: true, message: 'Categoría creada', category });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al crear categoría', error: err.message });
  }
}

// ✏️ Actualizar categoría
export async function updateCategory(req, res) {
  try {
    const category = await Category.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!category) return res.status(404).json({ success: false, message: 'Categoría no encontrada' });
    res.json({ success: true, message: 'Categoría actualizada', category });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al actualizar categoría', error: err.message });
  }
}

// 🗑️ Eliminar categoría
export async function deleteCategory(req, res) {
  try {
    const category = await Category.findByIdAndDelete(req.params.id);
    if (!category) return res.status(404).json({ success: false, message: 'Categoría no encontrada' });
    res.json({ success: true, message: 'Categoría eliminada' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error al eliminar categoría', error: err.message });
  }
}
