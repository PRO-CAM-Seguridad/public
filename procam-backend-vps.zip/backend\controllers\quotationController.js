import mongoose from 'mongoose';
import Quotation from '../models/Quotation.js';
import Prospect from '../models/Prospect.js';
import Campaign from '../models/Campaign.js';
import {
  sendQuotationNotificationToAdmin,
  sendConfirmationToProspect,
  sendProposalEmailToClient
} from '../services/emailService.js';

// Generador de número correlativo amigable: COT-2026-XXXX
async function generateQuotationNumber() {
  const year = new Date().getFullYear();
  const count = await Quotation.countDocuments();
  const sequence = String(count + 1).padStart(4, '0');
  return `COT-${year}-${sequence}`;
}

/**
 * 📝 Crear nueva Solicitud de Cotización (Acceso Público)
 */
export async function createQuotation(req, res) {
  try {
    const {
      nombre,
      empresa,
      tipoCliente = 'persona',
      email,
      telefono,
      localidad,
      direccion,
      observaciones,
      items,
      campaignRef = 'QR-WEB',
      sessionId
    } = req.body;

    // Validaciones esenciales
    if (!nombre || !nombre.trim()) {
      return res.status(400).json({ success: false, message: 'El nombre es obligatorio.' });
    }
    if (!email || !email.trim()) {
      return res.status(400).json({ success: false, message: 'El correo electrónico es obligatorio.' });
    }
    if (!telefono || !telefono.trim()) {
      return res.status(400).json({ success: false, message: 'El número de teléfono es obligatorio.' });
    }
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'El carrito de cotización debe contener al menos un producto o servicio.' });
    }

    const emailNormalizado = email.toLowerCase().trim();
    const codigoCampana = (campaignRef || 'QR-WEB').toUpperCase().trim();

    // 1. Crear o actualizar Prospecto comercial
    let prospect = await Prospect.findOne({ email: emailNormalizado });
    if (!prospect) {
      prospect = new Prospect({
        nombre: nombre.trim(),
        empresa: empresa?.trim(),
        tipoCliente,
        email: emailNormalizado,
        telefono: telefono.trim(),
        localidad: localidad?.trim(),
        direccion: direccion?.trim(),
        observaciones: observaciones?.trim(),
        campaignRef: codigoCampana,
        sessionId,
        estado: 'ABIERTO'
      });
      await prospect.save();
    } else {
      // Actualizar datos de contacto recientes
      prospect.nombre = nombre.trim();
      prospect.telefono = telefono.trim();
      if (empresa) prospect.empresa = empresa.trim();
      if (localidad) prospect.localidad = localidad.trim();
      if (observaciones) prospect.observaciones = observaciones.trim();
      prospect.campaignRef = codigoCampana;
      if (sessionId) prospect.sessionId = sessionId;
      await prospect.save();
    }

    // 2. Generar número correlativo
    const numero = await generateQuotationNumber();

    // 3. Crear registro de Cotización
    const quotation = new Quotation({
      numero,
      prospect: prospect._id,
      items: items.map(item => {
        const rawId = item.productId || item.id;
        const validId = rawId && mongoose.Types.ObjectId.isValid(rawId) ? rawId : null;
        return {
          productId: validId,
          nombre: item.nombre,
          segmento: item.segmento,
          nivel: item.nivel,
          categoria: item.categoria,
          unidad: item.unidad || 'Unidad',
          cantidad: Number(item.cantidad) || 1,
          notas: item.notas || ''
        };
      }),
      observaciones: observaciones?.trim(),
      campaignRef: codigoCampana,
      sessionId,
      estado: 'ABIERTO',
      historial: [
        {
          fecha: new Date(),
          estadoAnterior: '',
          estadoNuevo: 'ABIERTO',
          usuario: 'Sistema Web',
          comentario: 'Solicitud enviada por el visitante a través del Cotizador Online.'
        }
      ]
    });

    await quotation.save();

    // Actualizar prospecto con número de ticket asociado
    try {
      prospect.ticketNumero = quotation.numero;
      prospect.quotationId = quotation._id;
      await prospect.save();
    } catch (prErr) {
      console.warn('⚠️ No se pudo vincular ticket al prospecto:', prErr.message);
    }

    // 4. Actualizar métricas de campaña QR
    try {
      await Campaign.findOneAndUpdate(
        { codigo: codigoCampana },
        { $inc: { cotizaciones: 1 } },
        { upsert: false }
      );
    } catch (cmpErr) {
      console.warn('⚠️ No se pudo actualizar contador de campaña:', cmpErr.message);
    }

    // 5. Enviar notificaciones por correo de manera asíncrona (no bloquea al usuario)
    sendQuotationNotificationToAdmin({ quotation, prospect }).catch(e => console.error('Error email admin:', e));
    sendConfirmationToProspect({ quotation, prospect }).catch(e => console.error('Error email prospecto:', e));

    return res.status(201).json({
      success: true,
      message: '¡Cotización solicitada con éxito!',
      quotationNumber: quotation.numero,
      confirmationText: 'Recibimos tu solicitud correctamente. A la brevedad, un asesor técnico comercial de PRO CAM Seguridad se pondrá en contacto para analizar tu proyecto y enviarte una propuesta personalizada.',
      quotationId: quotation._id
    });

  } catch (error) {
    console.error('❌ Error al procesar solicitud de cotización:', error);
    return res.status(500).json({
      success: false,
      message: 'Ocurrió un error al procesar tu solicitud. Por favor intenta nuevamente o contáctanos por WhatsApp.',
      error: error.message
    });
  }
}

/**
 * 📋 Obtener todas las cotizaciones (Solo Administrador)
 */
export async function getAllQuotations(req, res) {
  try {
    const { estado, campaign, page = 1, limit = 50, search } = req.query;
    const query = {};

    if (estado) query.estado = estado;
    if (campaign) query.campaignRef = campaign.toUpperCase();

    const quotations = await Quotation.find(query)
      .populate('prospect', 'nombre email telefono empresa localidad estado')
      .sort({ fechaCreacion: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    const total = await Quotation.countDocuments(query);

    res.json({
      success: true,
      total,
      page: Number(page),
      totalPages: Math.ceil(total / limit),
      quotations
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener cotizaciones', error: error.message });
  }
}

/**
 * 🔍 Obtener cotización por ID (Solo Administrador)
 */
export async function getQuotationById(req, res) {
  try {
    const quotation = await Quotation.findById(req.params.id)
      .populate('prospect');

    if (!quotation) {
      return res.status(404).json({ success: false, message: 'Cotización no encontrada' });
    }

    res.json({ success: true, quotation });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener cotización', error: error.message });
  }
}

/**
 * ✏️ Actualizar estado de una cotización (Solo Administrador)
 */
export async function updateQuotationState(req, res) {
  try {
    const { estado, notasInternas, comentario } = req.body;
    const quotation = await Quotation.findById(req.params.id);

    if (!quotation) {
      return res.status(404).json({ success: false, message: 'Cotización no encontrada' });
    }

    const estadoAnterior = quotation.estado;
    if (estado) quotation.estado = estado;
    if (notasInternas !== undefined) quotation.notasInternas = notasInternas;

    quotation.historial.push({
      fecha: new Date(),
      estadoAnterior,
      estadoNuevo: estado || estadoAnterior,
      usuario: req.user?.email || 'Administrador',
      comentario: comentario || 'Actualización de estado en panel'
    });

    await quotation.save();

    // Sincronizar estado con el prospecto si corresponde
    if (estado === 'CERRADO') {
      await Prospect.findByIdAndUpdate(quotation.prospect, { estado: 'CERRADO' });
    } else if (estado === 'EN TRATAMIENTO') {
      await Prospect.findByIdAndUpdate(quotation.prospect, { estado: 'EN TRATAMIENTO' });
    }

    res.json({ success: true, message: 'Cotización actualizada con éxito', quotation });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al actualizar cotización', error: error.message });
  }
}

/**
 * ✉️ Responder cotización / Ticket comercial con Frame Institucional y Firma Digital
 */
export async function replyQuotation(req, res) {
  try {
    const {
      mensaje,
      precioPresupuestado,
      validezOferta,
      metodoEnvio = 'sistema',
      asesorNombre,
      asesorCargo,
      asesorTelefono,
      firmaDigital
    } = req.body;

    if (!mensaje || !mensaje.trim()) {
      return res.status(400).json({ success: false, message: 'El mensaje de respuesta es obligatorio.' });
    }

    const quotation = await Quotation.findById(req.params.id).populate('prospect');
    if (!quotation) {
      return res.status(404).json({ success: false, message: 'Cotización no encontrada' });
    }

    const nombreAsesor = asesorNombre || req.user?.nombre || 'Equipo Comercial PRO CAM';
    const cargoAsesor = asesorCargo || 'Asesor Técnico Comercial';
    const firma = firmaDigital || `${nombreAsesor} — ${cargoAsesor} | PRO CAM Seguridad`;

    const nuevaRespuesta = {
      fecha: new Date(),
      asesorNombre: nombreAsesor,
      asesorCargo: cargoAsesor,
      mensaje: mensaje.trim(),
      precioPresupuestado: precioPresupuestado?.trim() || '',
      validezOferta: validezOferta?.trim() || '15 días hábiles',
      metodoEnvio
    };

    quotation.respuestas.push(nuevaRespuesta);
    quotation.estado = 'COTIZADA';
    quotation.asesorAsignado = {
      nombre: nombreAsesor,
      cargo: cargoAsesor,
      telefono: asesorTelefono || '+54 11 2394 0806',
      email: req.user?.email || 'ventas@procamseguridad.com.ar',
      firmaDigital: firma
    };

    quotation.historial.push({
      fecha: new Date(),
      estadoAnterior: quotation.estado,
      estadoNuevo: 'COTIZADA',
      usuario: req.user?.email || nombreAsesor,
      comentario: `Respuesta de ticket enviada por ${nombreAsesor} (${cargoAsesor})`
    });

    await quotation.save();

    // Actualizar estado del prospecto asociado y registrar asesor y fecha de contacto
    if (quotation.prospect?._id) {
      const prospect = await Prospect.findById(quotation.prospect._id);
      if (prospect) {
        if (prospect.estado === 'ABIERTO' || prospect.estado === 'NUEVO') {
          prospect.estado = 'CONTACTADO';
        }
        prospect.asesorAsignado = quotation.asesorAsignado;
        prospect.fechaUltimoContacto = new Date();
        await prospect.save();
      }
    }

    res.json({
      success: true,
      message: 'Respuesta registrada con éxito.',
      quotation
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al responder cotización', error: error.message });
  }
}

/**
 * 🛠️ Modelar Propuesta Online de Cotización (Solo Asesor Comercial / Admin)
 */
export async function saveProposal(req, res) {
  try {
    const {
      items,
      subtotal,
      descuentoPorcentaje,
      descuentoMonto,
      recargoPorcentaje,
      recargoMonto,
      total,
      medioPago,
      mercadoPagoLink,
      promocion,
      propuestaTecnica,
      observaciones,
      estado,
      asesorNombre,
      asesorCargo,
      asesorTelefono,
      firmaDigital
    } = req.body;

    const quotation = await Quotation.findById(req.params.id).populate('prospect');
    if (!quotation) {
      return res.status(404).json({ success: false, message: 'Cotización no encontrada' });
    }

    if (Array.isArray(items)) {
      quotation.items = items.map(it => ({
        productId: it.productId || null,
        nombre: it.nombre,
        segmento: it.segmento || 'Hogar',
        nivel: it.nivel || 'Esencial',
        categoria: it.categoria || '',
        unidad: it.unidad || 'Unidad',
        cantidad: Number(it.cantidad) || 1,
        precioUnitario: Number(it.precioUnitario) || 0,
        subtotal: Number(it.subtotal) || ((Number(it.cantidad) || 1) * (Number(it.precioUnitario) || 0)),
        notas: it.notas || ''
      }));
    }

    if (subtotal !== undefined) quotation.subtotal = Number(subtotal) || 0;
    if (descuentoPorcentaje !== undefined) quotation.descuentoPorcentaje = Number(descuentoPorcentaje) || 0;
    if (descuentoMonto !== undefined) quotation.descuentoMonto = Number(descuentoMonto) || 0;
    if (recargoPorcentaje !== undefined) quotation.recargoPorcentaje = Number(recargoPorcentaje) || 0;
    if (recargoMonto !== undefined) quotation.recargoMonto = Number(recargoMonto) || 0;
    if (total !== undefined) quotation.total = Number(total) || 0;
    if (medioPago) quotation.medioPago = medioPago;
    if (mercadoPagoLink !== undefined) quotation.mercadoPagoLink = mercadoPagoLink.trim();
    if (promocion !== undefined) quotation.promocion = promocion.trim();
    if (propuestaTecnica !== undefined) quotation.propuestaTecnica = propuestaTecnica.trim();
    if (observaciones !== undefined) quotation.observaciones = observaciones.trim();

    const estadoAnterior = quotation.estado;
    if (estado) quotation.estado = estado;

    if (asesorNombre) {
      quotation.asesorAsignado = {
        userId: req.user?._id || quotation.asesorAsignado?.userId,
        nombre: asesorNombre.trim(),
        cargo: asesorCargo?.trim() || 'Asesor Técnico Comercial',
        telefono: asesorTelefono?.trim() || '+54 11 2394 0806',
        email: req.user?.email || 'ventas@procamseguridad.com.ar',
        firmaDigital: firmaDigital?.trim() || quotation.asesorAsignado?.firmaDigital || ''
      };
    }

    quotation.historial.push({
      fecha: new Date(),
      estadoAnterior,
      estadoNuevo: quotation.estado,
      usuario: req.user?.email || asesorNombre || 'Asesor Comercial',
      comentario: `Propuesta comercial modelada en línea (Total: $${Number(quotation.total).toLocaleString('es-AR')})`
    });

    await quotation.save();

    // Sincronizar con el prospecto
    if (quotation.prospect?._id) {
      await Prospect.findByIdAndUpdate(quotation.prospect._id, {
        asesorAsignado: quotation.asesorAsignado,
        estado: quotation.estado === 'COTIZADA' ? 'CONTACTADO' : undefined,
        fechaUltimoContacto: new Date()
      });
    }

    res.json({
      success: true,
      message: 'Propuesta modelada y guardada con éxito',
      quotation
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al modelar propuesta', error: error.message });
  }
}

/**
 * 📧 Enviar email formal con la propuesta y firma digital al prospecto
 */
export async function sendProposalEmail(req, res) {
  try {
    const quotation = await Quotation.findById(req.params.id).populate('prospect');
    if (!quotation) {
      return res.status(404).json({ success: false, message: 'Cotización no encontrada' });
    }

    const prospect = quotation.prospect;
    if (!prospect || !prospect.email) {
      return res.status(400).json({ success: false, message: 'El prospecto no posee email registrado' });
    }

    const { mensaje } = req.body;
    const advisor = quotation.asesorAsignado || {
      nombre: req.user?.nombre || 'Gonzalo Nicolás Rojas',
      cargo: 'Especialistas en soluciones integrales de seguridad electrónica',
      telefono: '+ 54 11 2394-0806'
    };

    const mailResult = await sendProposalEmailToClient({
      quotation,
      prospect,
      advisor,
      proposalDetails: { mensaje: mensaje || quotation.propuestaTecnica }
    });

    quotation.estado = 'COTIZADA';
    quotation.historial.push({
      fecha: new Date(),
      estadoAnterior: quotation.estado,
      estadoNuevo: 'COTIZADA',
      usuario: req.user?.email || advisor.nombre,
      comentario: `Propuesta formal enviada por correo electrónico a ${prospect.email}`
    });
    await quotation.save();

    res.json({
      success: true,
      message: `Presupuesto oficial enviado por correo electrónico a ${prospect.email}`,
      mailResult,
      quotation
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al enviar email de cotización', error: error.message });
  }
}

