import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  products: [
    {
      productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
      nombre: String,
      precio: Number,
      cantidad: Number
    }
  ],
  total: { type: Number, required: true },
  status: { type: String, enum: ['cart', 'pending', 'completed'], default: 'pending' },
  segmento: { type: String, enum: ['Hogar', 'Empresas', 'Smart'], default: 'Hogar' },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('Order', orderSchema);
