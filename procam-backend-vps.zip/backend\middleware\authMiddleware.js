import jwt from 'jsonwebtoken';

// Middleware básico: valida token
export function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.status(401).json({ message: 'Token no proporcionado' });

  const token = authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Token inválido' });

  try {
    const secret = process.env.JWT_SECRET || 'secretkey';
    const decoded = jwt.verify(token, secret);
    req.user = decoded; // guarda info del usuario (id, role, nombre, email)
    next();
  } catch (err) {
    return res.status(403).json({ message: 'Token inválido o expirado' });
  }
}

// Middleware extendido: valida rol admin, root o ventas
export async function adminMiddleware(req, res, next) {
  if (!req.user) return res.status(401).json({ message: 'No autenticado' });
  
  // Si por alguna razón el token no traía role, buscamos en DB
  if (!req.user.role && req.user.id) {
    try {
      const User = (await import('../models/User.js')).default;
      const dbUser = await User.findById(req.user.id);
      if (dbUser) req.user.role = dbUser.role;
    } catch (_) {}
  }

  const role = req.user.role;
  if (role !== 'admin' && role !== 'root' && role !== 'ventas') {
    return res.status(403).json({ message: 'Acceso denegado: se requiere rol de gestión (admin, root o ventas)' });
  }
  next();
}

// Middleware exclusivo: valida rol root
export function rootMiddleware(req, res, next) {
  if (!req.user) return res.status(401).json({ message: 'No autenticado' });
  if (req.user.role !== 'root') {
    return res.status(403).json({ message: 'Acceso denegado: se requiere rol root para editar la API' });
  }
  next();
}
