
import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({

  // =========================
  // DATOS DE ACCESO
  // =========================

  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },

  password: {
    type: String,
    required: true
  },

  // =========================
  // DATOS DEL CLIENTE
  // =========================

  nombre: {
    type: String,
    required: true,
    trim: true
  },

  tipoCliente: {
    type: String,
    enum: ['persona', 'empresa'],
    default: 'persona',
    required: true
  },

  telefono: {
    type: String,
    required: true,
    trim: true
  },

  tipoDocumento: {
    type: String,
    enum: ['DNI', 'CUIT'],
    required: true
  },

  numeroDocumento: {
    type: String,
    required: true,
    trim: true
  },

  fechaNacimiento: {
    type: Date
  },

  direccion: {
    type: String,
    trim: true
  },

  localidad: {
    type: String,
    trim: true
  },

  codigoPostal: {
    type: String,
    trim: true
  },

  // =========================
  // VERIFICACIÓN
  // =========================

  verified: {
    type: Boolean,
    default: false
  },

  verificationToken: {
    type: String,
    trim: true
  },

  verificationExpires: {
    type: Date
  },

  resetPasswordToken: {
    type: String,
    trim: true
  },

  resetPasswordExpires: {
    type: Date
  },

  // =========================
  // PERMISOS INTERNOS & CARGO
  // =========================

  role: {
    type: String,
    enum: ['user', 'ventas', 'admin', 'root'],
    default: 'user'
  },

  cargo: {
    type: String,
    default: 'Asesor Técnico Comercial'
  },

  fotoPerfil: {
    type: String,
    default: ''
  },

  firmaDigital: {
    type: String,
    default: ''
  },

  // =========================
  // REGISTRO
  // =========================

  fechaRegistro: {
    type: Date,
    default: Date.now
  }

});

export default mongoose.model('User', userSchema);

