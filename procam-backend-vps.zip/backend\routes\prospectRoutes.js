import express from 'express';
import {
  getAllProspects,
  getProspectById,
  updateProspect,
  assignAdvisor,
  deleteProspect,
  convertToQuotation,
  createPublicContactLead
} from '../controllers/prospectController.js';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// 📨 Registrar consulta pública desde formulario de contacto
router.post('/contact', createPublicContactLead);

// Todas las demás rutas de prospectos son administrativas
router.use(authMiddleware, adminMiddleware);

// 📋 Listar prospectos
router.get('/', getAllProspects);

// 🔎 Ver prospecto e historial
router.get('/:id', getProspectById);

// 📋 Convertir Prospecto a Cotización Oficial
router.post('/:id/convert-to-quotation', convertToQuotation);

// 👔 Asignar Asesor Comercial
router.put('/:id/assign', assignAdvisor);

// ✏️ Actualizar prospecto
router.put('/:id', updateProspect);

// 🗑️ Eliminar prospecto
router.delete('/:id', deleteProspect);

export default router;
